package org.example.facturaarca.web;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.example.facturaarca.entidades.FacturaVenta;
import org.example.facturaarca.repository.ClienteRepository;
import org.example.facturaarca.repository.CondicionIvaRepository;
import org.example.facturaarca.repository.FacturaVentaRepository;
import org.example.facturaarca.repository.ListaPrecioArticuloRepository;
import org.example.facturaarca.repository.PuntoVentaRepository;
import org.example.facturaarca.repository.TipoMonedaRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static org.hamcrest.Matchers.closeTo;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * Pruebas del CRUD de escritura: POST, PUT y DELETE de facturas de venta.
 *
 * <p>La clase es {@code @Transactional}: todo lo que se escribe se revierte
 * al terminar cada test, asi los datos sembrados siguen intactos para las
 * demas pruebas.
 */
@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
@Transactional
class FacturaCrudRestControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private ClienteRepository clienteRepository;

    @Autowired
    private CondicionIvaRepository condicionIvaRepository;

    @Autowired
    private PuntoVentaRepository puntoVentaRepository;

    @Autowired
    private TipoMonedaRepository tipoMonedaRepository;

    @Autowired
    private ListaPrecioArticuloRepository listaPrecioArticuloRepository;

    @Autowired
    private FacturaVentaRepository facturaVentaRepository;

    // ------------------------------------------------------------------
    // POST
    // ------------------------------------------------------------------

    @Test
    void creaUnaFacturaYDevuelve201ConElLocation() throws Exception {
        String cuerpo = json(facturaValida());

        mockMvc.perform(post("/api/facturas")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(cuerpo))
                .andExpect(status().isCreated())
                .andExpect(header().exists("Location"))
                .andExpect(jsonPath("$.numeroFactura", is(1013)))
                .andExpect(jsonPath("$.estado", is("EMITIDA")))
                .andExpect(jsonPath("$.cantidadItems", is(2)))
                .andExpect(jsonPath("$.importeTotal", is(closeTo(totalEsperado(), 0.0001))));
    }

    @Test
    void laFacturaCreadaQuedaPersistidaConSusDetalles() throws Exception {
        mockMvc.perform(post("/api/facturas")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json(facturaValida())))
                .andExpect(status().isCreated());

        FacturaVenta creada = facturaVentaRepository.findTopByOrderByNumeroDesc().orElseThrow();
        org.assertj.core.api.Assertions.assertThat(creada.getDetalles()).hasSize(2);
        org.assertj.core.api.Assertions.assertThat(creada.getImporteTotal()).isEqualTo(totalEsperado());
    }

    @Test
    void unaFacturaSinDetallesDevuelve400() throws Exception {
        Map<String, Object> request = facturaValida();
        request.put("detalles", List.of());

        mockMvc.perform(post("/api/facturas")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json(request)))
                .andExpect(status().isBadRequest());
    }

    @Test
    void unaFacturaSinFechaEmisionDevuelve400() throws Exception {
        Map<String, Object> request = facturaValida();
        request.remove("fechaEmision");

        mockMvc.perform(post("/api/facturas")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json(request)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.detalles[0]", notNullValue()));
    }

    @Test
    void unClienteQueNoExisteDevuelve404() throws Exception {
        Map<String, Object> request = facturaValida();
        request.put("clienteId", 999999L);

        mockMvc.perform(post("/api/facturas")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json(request)))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.mensaje", notNullValue()));
    }

    @Test
    void unNumeroDeFacturaRepetidoDevuelve400() throws Exception {
        Map<String, Object> request = facturaValida();
        request.put("numero", facturaExistente().getNumero());

        mockMvc.perform(post("/api/facturas")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json(request)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.mensaje", notNullValue()));
    }

    @Test
    void unArticuloSinPrecioDeListaDevuelve404() throws Exception {
        Map<String, Object> request = facturaValida();
        @SuppressWarnings("unchecked")
        List<Map<String, Object>> detalles = (List<Map<String, Object>>) request.get("detalles");
        ((Map<String, Object>) detalles.get(0)).put("articuloId", 999999L);

        mockMvc.perform(post("/api/facturas")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json(request)))
                .andExpect(status().isNotFound());
    }

    // ------------------------------------------------------------------
    // PUT
    // ------------------------------------------------------------------

    @Test
    void actualizaUnaFacturaYDevuelve200() throws Exception {
        Long id = facturaEditable().getId();

        Map<String, Object> request = facturaValida();
        request.put("observaciones", "Factura editada desde el test");

        mockMvc.perform(put("/api/facturas/" + id)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json(request)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id", is(id.intValue())));
    }

    @Test
    void actualizarUnaFacturaInexistenteDevuelve404() throws Exception {
        mockMvc.perform(put("/api/facturas/999999")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json(facturaValida())))
                .andExpect(status().isNotFound());
    }

    @Test
    void anularUnaFacturaLePoneElEstadoAnulada() throws Exception {
        Long id = facturaExistente().getId();

        mockMvc.perform(put("/api/facturas/" + id + "/estado")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json(Map.of("estado", "ANULADA", "observaciones", "Anulada por el test"))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.estado", is("ANULADA")));
    }

    @Test
    void unEstadoDesconocidoDevuelve400() throws Exception {
        Long id = facturaExistente().getId();

        mockMvc.perform(put("/api/facturas/" + id + "/estado")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json(Map.of("estado", "INVENTADO"))))
                .andExpect(status().isBadRequest());
    }

    @Test
    void sinEstadoDevuelve400() throws Exception {
        Long id = facturaExistente().getId();

        mockMvc.perform(put("/api/facturas/" + id + "/estado")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json(Map.of())))
                .andExpect(status().isBadRequest());
    }

    // ------------------------------------------------------------------
    // DELETE
    // ------------------------------------------------------------------

    @Test
    void eliminaUnaFacturaYDevuelve204() throws Exception {
        Long id = facturaExistente().getId();

        mockMvc.perform(delete("/api/facturas/" + id))
                .andExpect(status().isNoContent())
                .andExpect(org.springframework.test.web.servlet.result.MockMvcResultMatchers.content().string(""));

        org.assertj.core.api.Assertions.assertThat(facturaVentaRepository.findById(id)).isEmpty();
    }

    @Test
    void eliminarUnaFacturaInexistenteDevuelve404() throws Exception {
        mockMvc.perform(delete("/api/facturas/999999"))
                .andExpect(status().isNotFound());
    }

    // ------------------------------------------------------------------
    // GET por id y catalogos
    // ------------------------------------------------------------------

    @Test
    void buscaUnaFacturaPorId() throws Exception {
        Long id = facturaExistente().getId();

        mockMvc.perform(get("/api/facturas/" + id))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id", is(id.intValue())))
                .andExpect(jsonPath("$.estado", notNullValue()));
    }

    @Test
    void buscarUnaFacturaInexistenteDevuelve404() throws Exception {
        mockMvc.perform(get("/api/facturas/999999"))
                .andExpect(status().isNotFound());
    }

    @Test
    void devuelveLosCatalogosDelFormulario() throws Exception {
        mockMvc.perform(get("/api/catalogos"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.articulos.length()", is(7)))
                .andExpect(jsonPath("$.clientes.length()", is(4)))
                .andExpect(jsonPath("$.condicionesIva.length()", is(3)))
                .andExpect(jsonPath("$.puntosVenta.length()", is(3)))
                .andExpect(jsonPath("$.monedas.length()", is(1)))
                .andExpect(jsonPath("$.articulos[0].precio", notNullValue()));
    }

    // ------------------------------------------------------------------
    // Helpers
    // ------------------------------------------------------------------

    private FacturaVenta facturaExistente() {
        return facturaVentaRepository.findTopByOrderByNumeroDesc().orElseThrow();
    }

    /**
     * Factura que se puede editar: el servicio rechaza con 400 modificar una
     * factura anulada, asi que el test tiene que buscar una que no lo este.
     */
    private FacturaVenta facturaEditable() {
        return facturaVentaRepository.findAll().stream()
                .filter(factura -> !"ANULADA".equals(factura.getEstado()))
                .findFirst()
                .orElseThrow();
    }

    /** Factura de ejemplo: dos renglones de 8500 (mouse) y 17000. */
    private Map<String, Object> facturaValida() {
        Map<String, Object> request = new LinkedHashMap<>();
        request.put("fechaEmision", "2026-07-01");
        request.put("clienteId", clienteRepository.findAll().get(0).getId());
        request.put("condicionIvaId", condicionIvaRepository.findAll().get(0).getId());
        request.put("puntoVentaId", puntoVentaRepository.findAll().get(0).getId());
        request.put("tipoMonedaId", tipoMonedaRepository.findAll().get(0).getId());

        List<Map<String, Object>> detalles = new java.util.ArrayList<>();
        Map<String, Object> primerRenglon = new LinkedHashMap<>();
        primerRenglon.put("articuloId", articuloId(0));
        primerRenglon.put("cantidad", 2);
        detalles.add(primerRenglon);

        Map<String, Object> segundoRenglon = new LinkedHashMap<>();
        segundoRenglon.put("articuloId", articuloId(1));
        segundoRenglon.put("cantidad", 1);
        detalles.add(segundoRenglon);

        request.put("detalles", detalles);

        return request;
    }

    private Long articuloId(int posicion) {
        return listaPrecioArticuloRepository.listarConArticulo().get(posicion).getArticulo().getId();
    }

    /** Total que tiene que dar la factura de ejemplo: 2 del primer articulo + 1 del segundo. */
    private double totalEsperado() {
        var precios = listaPrecioArticuloRepository.listarConArticulo();
        return precios.get(0).getPrecioVenta() * 2 + precios.get(1).getPrecioVenta();
    }

    private String json(Object valor) throws Exception {
        return objectMapper.writeValueAsString(valor);
    }
}
