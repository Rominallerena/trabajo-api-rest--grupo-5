package org.example.facturaarca;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ActiveProfiles;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@ActiveProfiles("test")
class FacturaArcaApiApplicationTests {

    @Autowired
    private ApplicationContext contexto;

    @Test
    void elContextoLevantaConTodosLosBeans() {
        assertThat(contexto.containsBean("facturaService")).isTrue();
        assertThat(contexto.containsBean("facturaReporteRepository")).isTrue();
        assertThat(contexto.containsBean("facturaRestController")).isTrue();
        assertThat(contexto.getBeansOfType(
                org.example.facturaarca.service.reporte.GeneradorReporte.class)).hasSize(2);
    }
}
