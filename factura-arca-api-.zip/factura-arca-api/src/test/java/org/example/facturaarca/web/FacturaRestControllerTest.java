package org.example.facturaarca.web;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import static org.hamcrest.Matchers.everyItem;
import static org.hamcrest.Matchers.greaterThan;
import static org.hamcrest.Matchers.greaterThanOrEqualTo;
import static org.hamcrest.Matchers.is;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * Prueba de punta a punta del endpoint: JPQL con expresion de constructor,
 * filtros opcionales y serializacion JSON del DTO.
 */
@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
class FacturaRestControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Test
    void sinFiltrosDevuelveTodoElReporte() throws Exception {
        mockMvc.perform(get("/api/facturas"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()", is(12)))
                .andExpect(jsonPath("$[0].numeroFactura", is(1001)))
                .andExpect(jsonPath("$[0].cantidadItems", is(2)))
                .andExpect(jsonPath("$[0].fechaEmision", is("2026-01-15")));
    }

    @Test
    void elClienteNuloSeMuestraComoConsumidorFinal() throws Exception {
        mockMvc.perform(get("/api/facturas").param("estado", "EMITIDA"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].clienteDenominacion", is("Consumidor Final")));
    }

    @Test
    void filtraPorEstado() throws Exception {
        mockMvc.perform(get("/api/facturas").param("estado", "ANULADA"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()", is(2)))
                .andExpect(jsonPath("$[*].numeroFactura", everyItem(greaterThan(1000))));
    }

    @Test
    void filtraPorRangoDeFechas() throws Exception {
        // fechaHasta incluye el dia completo aunque la factura tenga hora.
        mockMvc.perform(get("/api/facturas")
                        .param("fechaDesde", "2026-01-01")
                        .param("fechaHasta", "2026-02-22"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()", is(4)));
    }

    @Test
    void filtraPorMontoMinimo() throws Exception {
        mockMvc.perform(get("/api/facturas").param("montoMinimo", "400000"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[*].importeTotal", everyItem(greaterThanOrEqualTo(400000.0))));
    }

    @Test
    void combinaVariosFiltros() throws Exception {
        mockMvc.perform(get("/api/facturas")
                        .param("estado", "AUTORIZADA")
                        .param("montoMinimo", "600000"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()", is(2)));
    }

    @Test
    void devuelveElReporteEnPdf() throws Exception {
        mockMvc.perform(get("/api/facturas/reporte").param("formato", "pdf"))
                .andExpect(status().isOk())
                .andExpect(result -> {
                    byte[] cuerpo = result.getResponse().getContentAsByteArray();
                    if (cuerpo.length < 1000 || cuerpo[0] != '%' || cuerpo[1] != 'P') {
                        throw new AssertionError("La respuesta no parece un PDF valido");
                    }
                });
    }

    @Test
    void devuelveElReporteEnExcel() throws Exception {
        mockMvc.perform(get("/api/facturas/reporte").param("formato", "xlsx"))
                .andExpect(status().isOk())
                .andExpect(result -> {
                    byte[] cuerpo = result.getResponse().getContentAsByteArray();
                    // Un .xlsx es un ZIP: tiene que empezar con PK.
                    if (cuerpo.length < 1000 || cuerpo[0] != 'P' || cuerpo[1] != 'K') {
                        throw new AssertionError("La respuesta no parece un XLSX valido");
                    }
                });
    }

    @Test
    void filtraPorNumeroExacto() throws Exception {
        mockMvc.perform(get("/api/facturas").param("numeroFactura", "1004"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()", is(1)))
                .andExpect(jsonPath("$[0].numeroFactura", is(1004)));
    }

    @Test
    void unNumeroInexistenteDevuelveListaVacia() throws Exception {
        mockMvc.perform(get("/api/facturas").param("numeroFactura", "999999"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()", is(0)));
    }

    @Test
    void filtraPorClienteSinImportarMayusculas() throws Exception {
        // Coincidencia parcial sobre Cliente.denominacion.
        mockMvc.perform(get("/api/facturas").param("clienteDenominacion", "del sur"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()", is(3)))
                .andExpect(jsonPath("$[*].clienteDenominacion",
                        everyItem(is("Distribuidora Del Sur SA"))));
    }

    @Test
    void elFiltroDeClienteAlcanzaAlConsumidorFinal() throws Exception {
        // Las facturas sin cliente se muestran como "Consumidor Final".
        mockMvc.perform(get("/api/facturas").param("clienteDenominacion", "consumidor"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()", is(3)))
                .andExpect(jsonPath("$[*].numeroFactura",
                        everyItem(is(org.hamcrest.Matchers.anyOf(is(1001), is(1005), is(1011))))));
    }

    @Test
    void filtraPorCondicionIva() throws Exception {
        mockMvc.perform(get("/api/facturas").param("condicionIva", "Monotributo"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()", is(3)))
                .andExpect(jsonPath("$[*].condicionIva", everyItem(is("Responsable Monotributo"))));
    }

    @Test
    void combinaClienteYCondicionIva() throws Exception {
        mockMvc.perform(get("/api/facturas")
                        .param("clienteDenominacion", "sur")
                        .param("condicionIva", "Monotributo"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()", is(1)))
                .andExpect(jsonPath("$[0].numeroFactura", is(1006)));
    }

    @Test
    void combinaNumeroYFecha() throws Exception {
        mockMvc.perform(get("/api/facturas")
                        .param("numeroFactura", "1004")
                        .param("fechaDesde", "2026-02-01")
                        .param("fechaHasta", "2026-02-28"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()", is(1)));

        mockMvc.perform(get("/api/facturas")
                        .param("numeroFactura", "1004")
                        .param("fechaDesde", "2026-03-01"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()", is(0)));
    }

    @Test
    void unFormatoDesconocidoDevuelve400() throws Exception {        mockMvc.perform(get("/api/facturas/reporte").param("formato", "docx"))
                .andExpect(status().isBadRequest());
    }

    @Test
    void unaFechaMalFormadaDevuelve400() throws Exception {
        mockMvc.perform(get("/api/facturas").param("fechaDesde", "15-01-2026"))
                .andExpect(status().isBadRequest());
    }
}
