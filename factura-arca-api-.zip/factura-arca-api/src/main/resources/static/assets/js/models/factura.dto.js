/**
 * Espejo en TypeScript de los DTOs de Java.
 *
 * Cada interface de este archivo corresponde, campo por campo, con una clase
 * del paquete `org.example.facturaarca.dto`. Si se cambia un DTO del backend,
 * hay que cambiar la interface de acá: es el "contrato" que comparten las dos
 * capas.
 *
 * - FacturaReporteDTO        <-> dto/FacturaReporteDTO.java
 * - FacturaRequestDTO        <-> dto/FacturaRequestDTO.java
 * - FacturaDetalleRequestDTO <-> dto/FacturaDetalleRequestDTO.java
 * - FacturaEstadoRequestDTO  <-> dto/FacturaEstadoRequestDTO.java
 * - CatalogoItemDTO          <-> dto/CatalogoItemDTO.java
 */
export const ESTADOS_FACTURA = [
    'EMITIDA',
    'AUTORIZADA',
    'ANULADA',
    'RECHAZADA'
];
/** Devuelve el dia de hoy en yyyy-MM-dd, que es el formato que espera la API. */
export function hoy() {
    const ahora = new Date();
    const mes = String(ahora.getMonth() + 1).padStart(2, '0');
    const dia = String(ahora.getDate()).padStart(2, '0');
    return `${ahora.getFullYear()}-${mes}-${dia}`;
}
/**
 * Renglon vacio para la tabla dinamica del formulario.
 * El precio se carga desde el catalogo cuando se elige el articulo.
 */
export function crearDetalleVacio() {
    return {
        articuloId: 0,
        cantidad: 1,
        precioUnitario: 0,
        porcentajeBonificacion: 0
    };
}
//# sourceMappingURL=factura.dto.js.map