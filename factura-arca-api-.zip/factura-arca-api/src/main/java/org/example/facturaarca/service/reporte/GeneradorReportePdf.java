package org.example.facturaarca.service.reporte;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import org.example.facturaarca.config.ReportesProperties;
import org.example.facturaarca.dto.FacturaReporteDTO;
import org.springframework.stereotype.Component;

import java.io.ByteArrayOutputStream;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * Reporte en PDF con iText 5. Recibe las filas ya proyectadas como DTO, asi
 * que no conoce ni a JPA ni a las entidades.
 */
@Component
public class GeneradorReportePdf implements GeneradorReporte {

    private static final String[] COLUMNAS = {
            "Nro.", "Fecha", "Cliente", "Condicion IVA", "Punto de venta", "Items", "Importe total"
    };
    private static final float[] ANCHOS = {8f, 12f, 28f, 20f, 18f, 7f, 15f};

    private final ReportesProperties propiedades;

    public GeneradorReportePdf(ReportesProperties propiedades) {
        this.propiedades = propiedades;
    }

    @Override
    public String formato() {
        return "pdf";
    }

    @Override
    public String contentType() {
        return "application/pdf";
    }

    @Override
    public byte[] generar(List<FacturaReporteDTO> filas) {
        SimpleDateFormat fmtFecha = new SimpleDateFormat(propiedades.getFormatoFecha());
        DecimalFormat fmtImporte = new DecimalFormat("#,##0.00");

        Document documento = new Document(PageSize.A4.rotate(), 30, 30, 36, 36);
        ByteArrayOutputStream salida = new ByteArrayOutputStream();

        try {
            PdfWriter.getInstance(documento, salida);
            documento.open();

            documento.add(titulo(propiedades.getTitulo()));
            documento.add(subtitulo(propiedades.getEmpresa()
                    + "  |  generado el " + fmtFecha.format(new Date())
                    + "  |  " + filas.size() + " factura(s)"));

            PdfPTable tabla = new PdfPTable(COLUMNAS.length);
            tabla.setWidthPercentage(100);
            tabla.setWidths(ANCHOS);
            tabla.setHeaderRows(1);
            for (String columna : COLUMNAS) {
                tabla.addCell(celdaEncabezado(columna));
            }

            double acumulado = 0;
            long items = 0;
            for (FacturaReporteDTO fila : filas) {
                tabla.addCell(celda(String.valueOf(fila.getNumeroFactura()), Element.ALIGN_RIGHT));
                tabla.addCell(celda(fila.getFechaEmision() == null
                        ? "" : fmtFecha.format(fila.getFechaEmision()), Element.ALIGN_CENTER));
                tabla.addCell(celda(fila.getClienteDenominacion(), Element.ALIGN_LEFT));
                tabla.addCell(celda(fila.getCondicionIva(), Element.ALIGN_LEFT));
                tabla.addCell(celda(fila.getPuntoVentaDescripcion(), Element.ALIGN_LEFT));
                tabla.addCell(celda(String.valueOf(fila.getCantidadItems()), Element.ALIGN_CENTER));
                tabla.addCell(celda("$ " + fmtImporte.format(fila.getImporteTotal()), Element.ALIGN_RIGHT));

                acumulado += fila.getImporteTotal();
                items += fila.getCantidadItems();
            }

            tabla.addCell(celdaTotal("TOTALES", Element.ALIGN_LEFT, 5));
            tabla.addCell(celdaTotal(String.valueOf(items), Element.ALIGN_CENTER, 1));
            tabla.addCell(celdaTotal("$ " + fmtImporte.format(acumulado), Element.ALIGN_RIGHT, 1));

            documento.add(tabla);
            documento.close();
        } catch (DocumentException e) {
            throw new IllegalStateException("No se pudo generar el PDF del reporte", e);
        }

        return salida.toByteArray();
    }

    private Paragraph titulo(String texto) {
        Paragraph p = new Paragraph(texto, FontFactory.getFont(FontFactory.HELVETICA_BOLD, 16));
        p.setAlignment(Element.ALIGN_CENTER);
        p.setSpacingAfter(4f);
        return p;
    }

    private Paragraph subtitulo(String texto) {
        Paragraph p = new Paragraph(texto, FontFactory.getFont(FontFactory.HELVETICA, 9, BaseColor.DARK_GRAY));
        p.setAlignment(Element.ALIGN_CENTER);
        p.setSpacingAfter(14f);
        return p;
    }

    private PdfPCell celdaEncabezado(String texto) {
        Font fuente = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 9, BaseColor.WHITE);
        PdfPCell celda = new PdfPCell(new Phrase(texto, fuente));
        celda.setBackgroundColor(new BaseColor(33, 70, 120));
        celda.setHorizontalAlignment(Element.ALIGN_CENTER);
        celda.setPadding(5f);
        return celda;
    }

    private PdfPCell celda(String texto, int alineacion) {
        PdfPCell celda = new PdfPCell(new Phrase(texto == null ? "" : texto,
                FontFactory.getFont(FontFactory.HELVETICA, 8)));
        celda.setHorizontalAlignment(alineacion);
        celda.setPadding(4f);
        return celda;
    }

    private PdfPCell celdaTotal(String texto, int alineacion, int colspan) {
        PdfPCell celda = new PdfPCell(new Phrase(texto,
                FontFactory.getFont(FontFactory.HELVETICA_BOLD, 9)));
        celda.setHorizontalAlignment(alineacion);
        celda.setColspan(colspan);
        celda.setBackgroundColor(new BaseColor(226, 232, 240));
        celda.setPadding(5f);
        return celda;
    }
}
