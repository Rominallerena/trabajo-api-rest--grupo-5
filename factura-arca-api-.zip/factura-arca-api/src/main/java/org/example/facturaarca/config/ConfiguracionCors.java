package org.example.facturaarca.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * Permite que el frontend se sirva desde otro origen (por ejemplo un
 * servidor estatico en el puerto 3000) durante el desarrollo.
 *
 * <p>Si el frontend se sirve desde la propia aplicacion (en
 * {@code /index.html}), el navegador no hace peticiones cross-origin y esta
 * configuracion no llega a ejecutarse.
 */
@Configuration
public class ConfiguracionCors implements WebMvcConfigurer {

    private final String[] origenes;

    public ConfiguracionCors(@Value("${app.cors.origins:*}") String[] origenes) {
        this.origenes = origenes;
    }

    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/api/**")
                .allowedOrigins(origenes)
                .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS")
                .allowedHeaders("*")
                .maxAge(3600);
    }
}
