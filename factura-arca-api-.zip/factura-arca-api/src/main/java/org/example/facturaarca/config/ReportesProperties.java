package org.example.facturaarca.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * Mapeo type-safe de las propiedades {@code app.reportes.*}.
 * Evita repartir media docena de {@code @Value} por las clases de reporte.
 */
@Getter
@Setter
@ConfigurationProperties(prefix = "app.reportes")
public class ReportesProperties {

    private String titulo = "Reporte Ejecutivo de Ventas";
    private String empresa = "FacturaArca";
    private String formatoFecha = "dd/MM/yyyy";

    /** Carpeta donde se escriben los archivos generados desde disco. */
    private String directorioSalida = "reportes";
}
