package org.example.facturaarca.repository;

import org.example.facturaarca.entidades.ListaPrecioArticulo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface ListaPrecioArticuloRepository extends JpaRepository<ListaPrecioArticulo, Long> {

    Optional<ListaPrecioArticulo> findFirstByArticulo_IdOrderByIdAsc(Long articuloId);

    @Query("SELECT l FROM ListaPrecioArticulo l JOIN FETCH l.articulo ORDER BY l.articulo.denominacion")
    List<ListaPrecioArticulo> listarConArticulo();
}
