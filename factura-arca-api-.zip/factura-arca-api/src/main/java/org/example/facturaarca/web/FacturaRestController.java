package org.example.facturaarca.web;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.example.facturaarca.dto.FacturaEstadoRequestDTO;
import org.example.facturaarca.dto.FacturaFiltro;
import org.example.facturaarca.dto.FacturaReporteDTO;
import org.example.facturaarca.dto.FacturaRequestDTO;
import org.example.facturaarca.service.FacturaService;
import org.example.facturaarca.service.ReporteFacturaService;
import org.example.facturaarca.service.ReporteGenerado;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.nio.file.Path;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

/**
 * API REST de facturas de venta.
 *
 * <p>{@code @RestController} = {@code @Controller} + {@code @ResponseBody}: lo
 * que devuelve cada metodo lo serializa Jackson a JSON, sin pasar por una
 * vista.
 *
 * <p>Los codigos de respuesta siguen la convencion HTTP:
 * {@code 201 Created} con el {@code Location} de la factura creada,
 * {@code 200 OK} en las actualizaciones y {@code 204 No Content} en el
 * borrado. Los errores los traduce {@link ManejadorErroresApi}.
 */
@RestController
@RequestMapping("/api/facturas")
@Tag(name = "Facturas de venta", description = "CRUD de facturas de venta y reportes de ventas")
public class FacturaRestController {

    private final FacturaService facturaService;
    private final ReporteFacturaService reporteFacturaService;

    public FacturaRestController(FacturaService facturaService,
                                 ReporteFacturaService reporteFacturaService) {
        this.facturaService = facturaService;
        this.reporteFacturaService = reporteFacturaService;
    }

    /**
     * GET /api/facturas
     *
     * <p>Todos los parametros son opcionales y se combinan entre si. Ejemplos:
     * <pre>
     * /api/facturas
     * /api/facturas?numeroFactura=1004
     * /api/facturas?clienteDenominacion=sur
     * /api/facturas?condicionIva=Monotributo
     * /api/facturas?fechaDesde=2026-01-01&amp;fechaHasta=2026-06-30
     * /api/facturas?montoMinimo=50000&amp;estado=AUTORIZADA
     * </pre>
     */
    @Operation(summary = "Listar facturas de venta",
            description = "Devuelve el reporte de facturas. Los filtros son opcionales y se combinan entre si.")
    @GetMapping
    public List<FacturaReporteDTO> listar(
            @Parameter(description = "Numero de comprobante")
            @RequestParam(required = false) Long numeroFactura,
            @Parameter(description = "Denominacion del cliente (coincidencia parcial)")
            @RequestParam(required = false) String clienteDenominacion,
            @Parameter(description = "Denominacion de la condicion de IVA (coincidencia parcial)")
            @RequestParam(required = false) String condicionIva,
            @Parameter(description = "Fecha de emision minima (yyyy-MM-dd)")
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fechaDesde,
            @Parameter(description = "Fecha de emision maxima (yyyy-MM-dd)")
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fechaHasta,
            @Parameter(description = "EMITIDA, AUTORIZADA, ANULADA o RECHAZADA")
            @RequestParam(required = false) String estado,
            @Parameter(description = "Importe total minimo de la factura")
            @RequestParam(required = false) Double montoMinimo) {

        return facturaService.buscarFacturas(FacturaFiltro.de(
                numeroFactura, clienteDenominacion, condicionIva,
                fechaDesde, fechaHasta, estado, montoMinimo));
    }

    /**
     * GET /api/facturas/{id}
     *
     * <p>Devuelve una sola factura. Si no existe, {@link ManejadorErroresApi}
     * la traduce a un 404.
     */
    @Operation(summary = "Obtener una factura por id")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Factura encontrada"),
            @ApiResponse(responseCode = "404", description = "No existe la factura con ese id")
    })
    @GetMapping("/{id}")
    public FacturaReporteDTO buscarPorId(@Parameter(description = "Id de la factura") @PathVariable Long id) {
        return facturaService.buscarPorId(id);
    }

    /**
     * GET /api/facturas/reporte?formato=pdf|xlsx
     * Descarga el mismo reporte, con los mismos filtros, como archivo.
     */
    @Operation(summary = "Descargar el reporte de ventas",
            description = "Genera el reporte en PDF o Excel con los filtros indicados.")
    @GetMapping("/reporte")
    public ResponseEntity<byte[]> descargarReporte(
            @RequestParam(defaultValue = "pdf") String formato,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fechaDesde,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fechaHasta,
            @RequestParam(required = false) String estado,
            @RequestParam(required = false) Double montoMinimo) {

        ReporteGenerado reporte = reporteFacturaService.generar(formato,
                FacturaFiltro.de(fechaDesde, fechaHasta, estado, montoMinimo));

        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType(reporte.contentType()))
                .header(HttpHeaders.CONTENT_DISPOSITION,
                        "attachment; filename=\"" + reporte.nombreArchivo() + "\"")
                .body(reporte.contenido());
    }

    /**
     * POST /api/facturas/reporte/archivos
     * Escribe el PDF y el Excel en la carpeta configurada y devuelve las rutas.
     */
    @Operation(summary = "Guardar el reporte en disco",
            description = "Escribe el PDF y el Excel en la carpeta configurada y devuelve las rutas.")
    @PostMapping("/reporte/archivos")
    public Map<String, Object> generarArchivos(
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fechaDesde,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fechaHasta,
            @RequestParam(required = false) String estado,
            @RequestParam(required = false) Double montoMinimo) {

        List<Path> rutas = reporteFacturaService.generarArchivos(
                FacturaFiltro.de(fechaDesde, fechaHasta, estado, montoMinimo));

        return Map.of(
                "cantidad", rutas.size(),
                "archivos", rutas.stream().map(Path::toString).toList());
    }

    /**
     * POST /api/facturas
     *
     * <p>Crea la factura con sus detalles en cascada. El cuerpo es un
     * {@link FacturaRequestDTO}: las relaciones viajan como ids, nunca como
     * objetos anidados.
     *
     * <p>Responde 201 Created con la cabecera {@code Location} apuntando a la
     * factura recien creada.
     */
    @Operation(summary = "Crear una factura de venta",
            description = "Crea la cabecera y sus detalles en cascada, calculando netos, IVA y total.")
    @ApiResponses({
            @ApiResponse(responseCode = "201", description = "Factura creada",
                    content = @Content(schema = @Schema(implementation = FacturaReporteDTO.class))),
            @ApiResponse(responseCode = "400", description = "El cuerpo no cumple las validaciones",
                    content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
            @ApiResponse(responseCode = "404", description = "Alguno de los ids enviados no existe",
                    content = @Content(schema = @Schema(implementation = ErrorResponse.class)))
    })
    @PostMapping
    public ResponseEntity<FacturaReporteDTO> crear(@Valid @RequestBody FacturaRequestDTO request) {
        FacturaReporteDTO creada = facturaService.crear(request);

        return ResponseEntity.status(HttpStatus.CREATED)
                .header(HttpHeaders.LOCATION, "/api/facturas/" + creada.getId())
                .body(creada);
    }

    /**
     * PUT /api/facturas/{id}
     *
     * <p>Actualiza la cabecera y los items de la factura indicada.
     */
    @Operation(summary = "Actualizar una factura de venta",
            description = "Reemplaza la cabecera y los detalles de la factura y recalcula los totales.")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Factura actualizada",
                    content = @Content(schema = @Schema(implementation = FacturaReporteDTO.class))),
            @ApiResponse(responseCode = "400", description = "El cuerpo no cumple las validaciones",
                    content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
            @ApiResponse(responseCode = "404", description = "No existe la factura con ese id",
                    content = @Content(schema = @Schema(implementation = ErrorResponse.class)))
    })
    @PutMapping("/{id}")
    public FacturaReporteDTO actualizar(@PathVariable Long id,
                                         @Valid @RequestBody FacturaRequestDTO request) {
        return facturaService.actualizar(id, request);
    }

    /**
     * PUT /api/facturas/{id}/estado
     *
     * <p>Cambia solo el estado de la factura. Es la operacion de anulacion
     * ({@code estado = ANULADA} con su fecha de anulacion) y la que usa el
     * boton "Anular" del frontend.
     */
    @Operation(summary = "Cambiar el estado de una factura",
            description = "Anula, autoriza, rechaza o emite la factura indicada.")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Estado actualizado",
                    content = @Content(schema = @Schema(implementation = FacturaReporteDTO.class))),
            @ApiResponse(responseCode = "400", description = "El estado no es valido",
                    content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
            @ApiResponse(responseCode = "404", description = "No existe la factura con ese id",
                    content = @Content(schema = @Schema(implementation = ErrorResponse.class)))
    })
    @PutMapping("/{id}/estado")
    public FacturaReporteDTO actualizarEstado(@PathVariable Long id,
                                              @Valid @RequestBody FacturaEstadoRequestDTO request) {
        return facturaService.actualizarEstado(id, request);
    }

    /**
     * DELETE /api/facturas/{id}
     *
     * <p>Elimina la factura y sus detalles. Responde 204 No Content, sin
     * cuerpo.
     */
    @Operation(summary = "Eliminar una factura de venta",
            description = "Borra la factura y sus detalles en cascada.")
    @ApiResponses({
            @ApiResponse(responseCode = "204", description = "Factura eliminada"),
            @ApiResponse(responseCode = "404", description = "No existe la factura con ese id",
                    content = @Content(schema = @Schema(implementation = ErrorResponse.class)))
    })
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        facturaService.eliminar(id);
        return ResponseEntity.noContent().build();
    }
}
