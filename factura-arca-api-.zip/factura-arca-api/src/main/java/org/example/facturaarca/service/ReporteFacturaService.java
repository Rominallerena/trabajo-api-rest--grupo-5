package org.example.facturaarca.service;

import org.example.facturaarca.config.ReportesProperties;
import org.example.facturaarca.dto.FacturaFiltro;
import org.example.facturaarca.dto.FacturaReporteDTO;
import org.example.facturaarca.service.reporte.GeneradorReporte;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * Orquesta la generacion de reportes: pide las filas a {@link FacturaService} y
 * delega el armado del archivo al {@link GeneradorReporte} del formato pedido.
 *
 * <p>Spring inyecta por constructor la lista completa de generadores que
 * encontro en el contexto, que se indexa por formato. Agregar un formato nuevo
 * es agregar un {@code @Component}: esta clase no cambia.
 */
@Service
public class ReporteFacturaService {

    private static final Logger log = LoggerFactory.getLogger(ReporteFacturaService.class);
    private static final DateTimeFormatter SELLO = DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss");

    private final FacturaService facturaService;
    private final ReportesProperties propiedades;
    private final Map<String, GeneradorReporte> generadores;

    public ReporteFacturaService(FacturaService facturaService,
                                 ReportesProperties propiedades,
                                 List<GeneradorReporte> generadores) {
        this.facturaService = facturaService;
        this.propiedades = propiedades;
        this.generadores = generadores.stream().collect(Collectors.toMap(
                GeneradorReporte::formato,
                Function.identity(),
                (a, b) -> a,
                LinkedHashMap::new));
        log.info("Formatos de reporte disponibles: {}", this.generadores.keySet());
    }

    public List<String> formatosDisponibles() {
        return List.copyOf(generadores.keySet());
    }

    public ReporteGenerado generar(String formato, FacturaFiltro filtro) {
        GeneradorReporte generador = generadores.get(formato == null ? "" : formato.toLowerCase());
        if (generador == null) {
            throw new FormatoReporteNoSoportadoException(formato, formatosDisponibles());
        }

        List<FacturaReporteDTO> filas = facturaService.buscarFacturas(filtro);
        byte[] contenido = generador.generar(filas);
        String nombre = "reporte-ventas-" + LocalDateTime.now().format(SELLO) + "." + generador.formato();

        log.info("Reporte {} generado con {} fila(s), {} bytes", formato, filas.size(), contenido.length);
        return new ReporteGenerado(nombre, generador.contentType(), contenido);
    }

    /**
     * Escribe en disco un archivo por cada formato registrado (PDF y Excel).
     * Es la version "2 archivos" que pide la Parte 2 del enunciado.
     */
    public List<Path> generarArchivos(FacturaFiltro filtro) {
        Path directorio = Paths.get(propiedades.getDirectorioSalida()).toAbsolutePath();
        List<Path> generados = new ArrayList<>();
        try {
            Files.createDirectories(directorio);
            for (String formato : generadores.keySet()) {
                ReporteGenerado reporte = generar(formato, filtro);
                Path destino = directorio.resolve(reporte.nombreArchivo());
                Files.write(destino, reporte.contenido());
                generados.add(destino);
                log.info("Archivo escrito en {}", destino);
            }
        } catch (IOException e) {
            throw new UncheckedIOException("No se pudieron escribir los reportes en " + directorio, e);
        }
        return generados;
    }
}
