package org.example.facturaarca.repository;

import org.example.facturaarca.entidades.PuntoVenta;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PuntoVentaRepository extends JpaRepository<PuntoVenta, Long> {
}
