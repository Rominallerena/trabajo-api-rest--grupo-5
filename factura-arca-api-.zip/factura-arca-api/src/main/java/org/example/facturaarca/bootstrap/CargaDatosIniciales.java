package org.example.facturaarca.bootstrap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

/**
 * Siembra el juego de datos de prueba al arrancar.
 *
 * <p>Se activa solo con {@code app.seed.enabled=true} (perfil dev). El trabajo
 * real vive en {@link SeedDatosService} y no aca: si el metodo transaccional
 * estuviera en esta misma clase, llamarlo desde {@code run()} lo invocaria
 * sobre {@code this} y se saltearia el proxy que abre la transaccion.
 */
@Component
@ConditionalOnProperty(name = "app.seed.enabled", havingValue = "true")
public class CargaDatosIniciales implements CommandLineRunner {

    private static final Logger log = LoggerFactory.getLogger(CargaDatosIniciales.class);

    private final SeedDatosService seedDatosService;

    public CargaDatosIniciales(SeedDatosService seedDatosService) {
        this.seedDatosService = seedDatosService;
    }

    @Override
    public void run(String... args) {
        if (seedDatosService.hayDatos()) {
            log.info("La base ya tiene facturas cargadas: no se siembran datos de prueba.");
            return;
        }
        int facturas = seedDatosService.sembrar();
        log.info("Datos de prueba cargados: {} facturas de venta.", facturas);
    }
}
