package org.example.facturaarca.web;

import lombok.Getter;
import lombok.Setter;
import org.springframework.http.HttpStatus;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Cuerpo uniforme de error de la API, como pide el apunte de
 * {@code @ControllerAdvice}: fecha + status + mensaje + detalles.
 *
 * <p>Es el mismo formato para todos los errores de negocio, asi el frontend
 * puede parsearlos sin preguntar de que endpoint vienen.
 */
@Getter
@Setter
public class ErrorResponse {

    private int status;
    private String mensaje;
    private LocalDateTime fecha;
    private List<String> detalles = new ArrayList<>();

    public ErrorResponse(int status, String mensaje) {
        this.status = status;
        this.mensaje = mensaje;
        this.fecha = LocalDateTime.now();
    }

    public ErrorResponse(HttpStatus status, String mensaje, List<String> detalles) {
        this.status = status.value();
        this.mensaje = mensaje;
        this.fecha = LocalDateTime.now();
        this.detalles = detalles == null ? new ArrayList<>() : new ArrayList<>(detalles);
    }

    /** Agrega un detalle al error y devuelve el mismo objeto. */
    public ErrorResponse conDetalle(String detalle) {
        this.detalles.add(detalle);
        return this;
    }
}
