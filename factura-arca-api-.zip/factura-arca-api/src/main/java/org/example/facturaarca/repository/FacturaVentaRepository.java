package org.example.facturaarca.repository;

import org.example.facturaarca.entidades.FacturaVenta;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface FacturaVentaRepository extends JpaRepository<FacturaVenta, Long> {

    boolean existsByNumero(Long numero);

    Optional<FacturaVenta> findTopByOrderByNumeroDesc();

    @Query("SELECT f FROM FacturaVenta f LEFT JOIN FETCH f.detalles WHERE f.id = :id")
    Optional<FacturaVenta> buscarConDetalles(@Param("id") Long id);
}
