package org.example.facturaarca.repository;

import org.example.facturaarca.entidades.CondicionIva;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CondicionIvaRepository extends JpaRepository<CondicionIva, Long> {
}
