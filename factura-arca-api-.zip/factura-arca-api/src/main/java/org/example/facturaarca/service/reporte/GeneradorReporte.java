package org.example.facturaarca.service.reporte;

import org.example.facturaarca.dto.FacturaReporteDTO;

import java.util.List;

/**
 * Contrato comun de los generadores de reporte. Cada implementacion es un bean
 * y {@link ReporteFacturaService} los recibe a todos en una lista, asi que
 * sumar un formato nuevo (CSV, HTML) no obliga a tocar al que los usa.
 */
public interface GeneradorReporte {

    /** Clave con la que se pide el formato desde la API: {@code pdf}, {@code xlsx}. */
    String formato();

    /** Content-Type con el que se devuelve el archivo por HTTP. */
    String contentType();

    byte[] generar(List<FacturaReporteDTO> filas);
}
