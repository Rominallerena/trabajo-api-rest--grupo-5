package org.example.facturaarca.service;

import java.util.List;

/** Se pidio un formato de reporte para el que no hay ningun generador registrado. */
public class FormatoReporteNoSoportadoException extends RuntimeException {

    public FormatoReporteNoSoportadoException(String formato, List<String> disponibles) {
        super("Formato de reporte no soportado: '" + formato + "'. Disponibles: " + disponibles);
    }
}
