package org.example.facturaarca.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.util.Date;

/**
 * Agrupa los filtros opcionales del endpoint para no arrastrar una lista de
 * parametros sueltos entre el controlador, el servicio y el repositorio.
 * Cualquier campo en null significa "sin filtrar por esto".
 *
 * <p>Las fechas se guardan como {@link Date} porque es el tipo que mapea
 * {@code FacturaVenta.fechaEmision} y contra el que compara la consulta JPQL.
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
public class FacturaFiltro {

    /** Numero de comprobante (FacturaVenta.numero). */
    private Long numeroFactura;

    /** Denominacion del cliente (Cliente.denominacion). Null = Consumidor Final. */
    private String clienteDenominacion;

    /** Denominacion de la condicion de IVA (CondicionIva.denominacion). */
    private String condicionIva;

    private Date fechaDesde;
    private Date fechaHasta;
    private String estado;
    private Double montoMinimo;

    /**
     * Construye el filtro con los cinco filtros del CRUD (numero, cliente,
     * condicion de IVA y rango de fechas) mas los dos del reporte (estado y
     * monto minimo).
     *
     * <p>El endpoint recibe fechas sin hora, pero {@code fechaEmision} si la
     * tiene: {@code fechaDesde} se ancla al comienzo del dia y
     * {@code fechaHasta} al ultimo instante, de modo que un rango
     * {@code 2026-01-01..2026-02-22} incluya a una factura del 22 a las 16:40.
     *
     * <p>Se usa {@link LocalDate} y no {@link Date} en la firma del
     * controlador a proposito: Spring parsea las fechas ISO de los
     * {@code @RequestParam} en UTC, asi que un {@code java.util.Date} caeria
     * en el dia anterior para cualquier zona al oeste de Greenwich.
     */
    public static FacturaFiltro de(Long numeroFactura, String clienteDenominacion, String condicionIva,
                                   LocalDate fechaDesde, LocalDate fechaHasta,
                                   String estado, Double montoMinimo) {
        return FacturaFiltro.builder()
                .numeroFactura(numeroFactura)
                .clienteDenominacion(texto(clienteDenominacion))
                .condicionIva(texto(condicionIva))
                .fechaDesde(aFecha(fechaDesde, LocalTime.MIN))
                .fechaHasta(aFecha(fechaHasta, LocalTime.MAX))
                .estado(texto(estado))
                .montoMinimo(montoMinimo)
                .build();
    }

    /** Sobrecarga para los endpoints de reporte, que solo usan estos cuatro. */
    public static FacturaFiltro de(LocalDate fechaDesde, LocalDate fechaHasta,
                                   String estado, Double montoMinimo) {
        return de(null, null, null, fechaDesde, fechaHasta, estado, montoMinimo);
    }

    public boolean sinFiltros() {
        return numeroFactura == null
                && clienteDenominacion == null
                && condicionIva == null
                && fechaDesde == null && fechaHasta == null
                && estado == null
                && montoMinimo == null;
    }

    /** Normaliza los textos: sin espacios y en null cuando vienen vacios. */
    private static String texto(String valor) {
        if (valor == null) {
            return null;
        }
        String limpio = valor.trim();
        return limpio.isEmpty() ? null : limpio;
    }


    private static Date aFecha(LocalDate dia, LocalTime hora) {
        return dia == null
                ? null
                : Date.from(dia.atTime(hora).atZone(ZoneId.systemDefault()).toInstant());
    }
}
