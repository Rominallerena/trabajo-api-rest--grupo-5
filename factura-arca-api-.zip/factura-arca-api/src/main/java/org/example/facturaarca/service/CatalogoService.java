package org.example.facturaarca.service;

import org.example.facturaarca.dto.CatalogoItemDTO;
import org.example.facturaarca.entidades.ListaPrecioArticulo;
import org.example.facturaarca.repository.ClienteRepository;
import org.example.facturaarca.repository.CondicionIvaRepository;
import org.example.facturaarca.repository.ListaPrecioArticuloRepository;
import org.example.facturaarca.repository.PuntoVentaRepository;
import org.example.facturaarca.repository.TipoMonedaRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Catalogos que necesita el formulario del frontend para elegir cliente,
 * condicion de IVA, punto de venta, moneda y articulos.
 *
 * <p>Todos devuelven el mismo tipo plano {@link CatalogoItemDTO}: id,
 * denominacion y (opcionalmente) precio. Es el mismo formato que usa el
 * enunciado para no obligar al frontend a conocer el modelo JPA.
 */
@Service
public class CatalogoService {

    private final ListaPrecioArticuloRepository listaPrecioArticuloRepository;
    private final ClienteRepository clienteRepository;
    private final CondicionIvaRepository condicionIvaRepository;
    private final PuntoVentaRepository puntoVentaRepository;
    private final TipoMonedaRepository tipoMonedaRepository;

    public CatalogoService(ListaPrecioArticuloRepository listaPrecioArticuloRepository,
                           ClienteRepository clienteRepository,
                           CondicionIvaRepository condicionIvaRepository,
                           PuntoVentaRepository puntoVentaRepository,
                           TipoMonedaRepository tipoMonedaRepository) {
        this.listaPrecioArticuloRepository = listaPrecioArticuloRepository;
        this.clienteRepository = clienteRepository;
        this.condicionIvaRepository = condicionIvaRepository;
        this.puntoVentaRepository = puntoVentaRepository;
        this.tipoMonedaRepository = tipoMonedaRepository;
    }

    /**
     * Articulos con su precio de venta.
     *
     * <p>El id que viaja es el del {@code Articulo}, que es el que espera
     * {@code FacturaDetalleRequestDTO.articuloId}. Si un articulo tiene mas de
     * una lista de precios, se muestra el mismo que resuelve el servicio al
     * armar el detalle: el de menor id.
     */
    @Transactional(readOnly = true)
    public List<CatalogoItemDTO> articulos() {
        Map<Long, ListaPrecioArticulo> porArticulo = new LinkedHashMap<>();
        for (ListaPrecioArticulo precio : listaPrecioArticuloRepository.listarConArticulo()) {
            porArticulo.merge(precio.getArticulo().getId(), precio,
                    (a, b) -> a.getId() <= b.getId() ? a : b);
        }

        return porArticulo.values().stream()
                .map(precio -> new CatalogoItemDTO(
                        precio.getArticulo().getId(),
                        precio.getArticulo().getDenominacion(),
                        precio.getPrecioVenta()))
                .toList();
    }

    @Transactional(readOnly = true)
    public List<CatalogoItemDTO> clientes() {
        return clienteRepository.findAll().stream()
                .map(cliente -> new CatalogoItemDTO(cliente.getId(), cliente.getDenominacion(), null))
                .toList();
    }

    @Transactional(readOnly = true)
    public List<CatalogoItemDTO> condicionesIva() {
        return condicionIvaRepository.findAll().stream()
                .map(condicion -> new CatalogoItemDTO(condicion.getId(), condicion.getDenominacion(), null))
                .toList();
    }

    @Transactional(readOnly = true)
    public List<CatalogoItemDTO> puntosVenta() {
        return puntoVentaRepository.findAll().stream()
                .map(punto -> new CatalogoItemDTO(punto.getId(), punto.getDescripcion(), null))
                .toList();
    }

    @Transactional(readOnly = true)
    public List<CatalogoItemDTO> monedas() {
        return tipoMonedaRepository.findAll().stream()
                .map(moneda -> new CatalogoItemDTO(moneda.getId(),
                        moneda.getDenominacion() + " (" + moneda.getSimbolo() + ")", null))
                .toList();
    }

    /** Todos los catalogos en una sola llamada, que es como los carga el frontend. */
    @Transactional(readOnly = true)
    public Map<String, List<CatalogoItemDTO>> todos() {
        Map<String, List<CatalogoItemDTO>> catalogos = new LinkedHashMap<>();
        catalogos.put("articulos", articulos());
        catalogos.put("clientes", clientes());
        catalogos.put("condicionesIva", condicionesIva());
        catalogos.put("puntosVenta", puntosVenta());
        catalogos.put("monedas", monedas());
        return catalogos;
    }
}
