package org.example.facturaarca.service;

import org.example.facturaarca.dto.FacturaDetalleRequestDTO;
import org.example.facturaarca.dto.FacturaEstadoRequestDTO;
import org.example.facturaarca.dto.FacturaFiltro;
import org.example.facturaarca.dto.FacturaReporteDTO;
import org.example.facturaarca.dto.FacturaRequestDTO;
import org.example.facturaarca.entidades.Cliente;
import org.example.facturaarca.entidades.CondicionIva;
import org.example.facturaarca.entidades.EstadoFactura;
import org.example.facturaarca.entidades.FacturaVenta;
import org.example.facturaarca.entidades.FacturaVentaDetalle;
import org.example.facturaarca.entidades.ListaPrecioArticulo;
import org.example.facturaarca.entidades.PuntoVenta;
import org.example.facturaarca.entidades.TipoMoneda;
import org.example.facturaarca.entidades.Usuario;
import org.example.facturaarca.repository.ClienteRepository;
import org.example.facturaarca.repository.CondicionIvaRepository;
import org.example.facturaarca.repository.FacturaReporteRepository;
import org.example.facturaarca.repository.FacturaVentaRepository;
import org.example.facturaarca.repository.ListaPrecioArticuloRepository;
import org.example.facturaarca.repository.PuntoVentaRepository;
import org.example.facturaarca.repository.TipoMonedaRepository;
import org.example.facturaarca.repository.UsuarioRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;

@Service
public class FacturaService {

    private static final Logger log = LoggerFactory.getLogger(FacturaService.class);
    private static final double ALICUOTA_IVA = 0.21;

    private final FacturaReporteRepository facturaReporteRepository;
    private final FacturaVentaRepository facturaVentaRepository;
    private final ClienteRepository clienteRepository;
    private final CondicionIvaRepository condicionIvaRepository;
    private final PuntoVentaRepository puntoVentaRepository;
    private final TipoMonedaRepository tipoMonedaRepository;
    private final ListaPrecioArticuloRepository listaPrecioArticuloRepository;
    private final UsuarioRepository usuarioRepository;

    public FacturaService(FacturaReporteRepository facturaReporteRepository,
                          FacturaVentaRepository facturaVentaRepository,
                          ClienteRepository clienteRepository,
                          CondicionIvaRepository condicionIvaRepository,
                          PuntoVentaRepository puntoVentaRepository,
                          TipoMonedaRepository tipoMonedaRepository,
                          ListaPrecioArticuloRepository listaPrecioArticuloRepository,
                          UsuarioRepository usuarioRepository) {
        this.facturaReporteRepository = facturaReporteRepository;
        this.facturaVentaRepository = facturaVentaRepository;
        this.clienteRepository = clienteRepository;
        this.condicionIvaRepository = condicionIvaRepository;
        this.puntoVentaRepository = puntoVentaRepository;
        this.tipoMonedaRepository = tipoMonedaRepository;
        this.listaPrecioArticuloRepository = listaPrecioArticuloRepository;
        this.usuarioRepository = usuarioRepository;
    }

    @Transactional(readOnly = true)
    public List<FacturaReporteDTO> buscarFacturas(FacturaFiltro filtro) {
        if (filtro == null || filtro.sinFiltros()) {
            return facturaReporteRepository.listarReporteCompleto();
        }
        return facturaReporteRepository.buscarFacturasFiltradas(filtro);
    }

    @Transactional(readOnly = true)
    public FacturaReporteDTO buscarPorId(Long id) {
        FacturaReporteDTO dto = facturaReporteRepository.buscarReportePorId(id);
        if (dto == null) {
            throw new RecursoNoEncontradoException("No existe la factura con id " + id);
        }
        return dto;
    }

    @Transactional
    public FacturaReporteDTO crear(FacturaRequestDTO request) {
        FacturaVenta factura = new FacturaVenta();
        mapearCabecera(factura, request);
        long numero = request.getNumero() != null ? request.getNumero() : siguienteNumero();
        if (facturaVentaRepository.existsByNumero(numero)) {
            throw new IllegalArgumentException("Ya existe una factura con el numero " + numero);
        }
        factura.setNumero(numero);
        factura.setEstado(estadoODefault(request.getEstado(), "EMITIDA"));
        reemplazarDetalles(factura, request.getDetalles());
        recalcularTotales(factura);
        auditarAlta(factura);
        facturaVentaRepository.save(factura);
        log.info("Factura {} creada con id {} y {} items", factura.getNumero(), factura.getId(),
                factura.getDetalles().size());
        return buscarPorId(factura.getId());
    }

    @Transactional
    public FacturaReporteDTO actualizar(Long id, FacturaRequestDTO request) {
        FacturaVenta factura = facturaVentaRepository.buscarConDetalles(id)
                .orElseThrow(() -> new RecursoNoEncontradoException("No existe la factura con id " + id));
        if (EstadoFactura.ANULADA.name().equalsIgnoreCase(factura.getEstado())) {
            throw new IllegalArgumentException("No se puede modificar una factura anulada");
        }
        mapearCabecera(factura, request);
        if (request.getNumero() != null) {
            if (!request.getNumero().equals(factura.getNumero())
                    && facturaVentaRepository.existsByNumero(request.getNumero())) {
                throw new IllegalArgumentException("Ya existe una factura con el numero " + request.getNumero());
            }
            factura.setNumero(request.getNumero());
        }
        if (request.getEstado() != null && !request.getEstado().isBlank()) {
            factura.setEstado(EstadoFactura.fromNombre(request.getEstado()).name());
        }
        reemplazarDetalles(factura, request.getDetalles());
        recalcularTotales(factura);
        auditarModificacion(factura);
        facturaVentaRepository.save(factura);
        return buscarPorId(factura.getId());
    }

    @Transactional
    public FacturaReporteDTO actualizarEstado(Long id, FacturaEstadoRequestDTO request) {
        FacturaVenta factura = facturaVentaRepository.findById(id)
                .orElseThrow(() -> new RecursoNoEncontradoException("No existe la factura con id " + id));
        String estado = EstadoFactura.fromNombre(request.getEstado()).name();
        factura.setEstado(estado);
        factura.setObservaciones(request.getObservaciones());
        if (EstadoFactura.ANULADA.name().equals(estado)) {
            factura.setFechaAnulacion(new Date());
        }
        auditarModificacion(factura);
        facturaVentaRepository.save(factura);
        return buscarPorId(factura.getId());
    }

    /** Eliminacion fisica: la cabecera y los detalles salen juntos por CascadeType.ALL. */
    @Transactional
    public void eliminar(Long id) {
        FacturaVenta factura = facturaVentaRepository.findById(id)
                .orElseThrow(() -> new RecursoNoEncontradoException("No existe la factura con id " + id));
        facturaVentaRepository.delete(factura);
        log.info("Factura id {} eliminada", id);
    }

    private void mapearCabecera(FacturaVenta factura, FacturaRequestDTO request) {
        factura.setFechaEmision(aDate(request.getFechaEmision()));
        factura.setCliente(buscarCliente(request.getClienteId()));
        factura.setCondicionIva(buscar(condicionIvaRepository, request.getCondicionIvaId(), "Condicion IVA"));
        factura.setPuntoVenta(buscar(puntoVentaRepository, request.getPuntoVentaId(), "Punto de venta"));
        factura.setTipoMoneda(buscar(tipoMonedaRepository, request.getTipoMonedaId(), "Tipo de moneda"));
        factura.setObservaciones(request.getObservaciones());
    }

    private void reemplazarDetalles(FacturaVenta factura, List<FacturaDetalleRequestDTO> renglones) {
        factura.getDetalles().clear();
        for (FacturaDetalleRequestDTO renglon : renglones) {
            ListaPrecioArticulo lpa = listaPrecioArticuloRepository
                    .findFirstByArticulo_IdOrderByIdAsc(renglon.getArticuloId())
                    .orElseThrow(() -> new RecursoNoEncontradoException(
                            "No existe precio de lista para el articulo " + renglon.getArticuloId()));

            double cantidad = renglon.getCantidad();
            double precio = renglon.getPrecioUnitario() != null
                    ? renglon.getPrecioUnitario()
                    : lpa.getPrecioVenta();
            double bonif = renglon.getPorcentajeBonificacion() == null ? 0 : renglon.getPorcentajeBonificacion();
            double neto = cantidad * precio * (1 - bonif / 100.0);

            FacturaVentaDetalle detalle = FacturaVentaDetalle.builder()
                    .listaPrecioArticulo(lpa)
                    .descripcion(lpa.getArticulo().getDenominacion())
                    .cantidad(cantidad)
                    .precioUnitario(precio)
                    .porcentajeBonificacion(bonif)
                    .importeNeto(neto)
                    .importeIva(neto * ALICUOTA_IVA)
                    .importeSubtotal(neto)
                    .build();
            factura.addDetalle(detalle);
        }
    }

    private void recalcularTotales(FacturaVenta factura) {
        double total = factura.getDetalles().stream()
                .mapToDouble(FacturaVentaDetalle::getImporteSubtotal)
                .sum();
        factura.setImporteTotal(total);
        factura.setImporteSaldo(total);
        factura.setImporteCobrado(0);
    }

    private Cliente buscarCliente(Long clienteId) {
        if (clienteId == null) {
            return null;
        }
        return clienteRepository.findById(clienteId)
                .orElseThrow(() -> new RecursoNoEncontradoException("No existe el cliente con id " + clienteId));
    }

    private <T> T buscar(org.springframework.data.jpa.repository.JpaRepository<T, Long> repo, Long id, String nombre) {
        return repo.findById(id)
                .orElseThrow(() -> new RecursoNoEncontradoException("No existe " + nombre + " con id " + id));
    }

    private long siguienteNumero() {
        return facturaVentaRepository.findTopByOrderByNumeroDesc()
                .map(f -> f.getNumero() == null ? 1000L : f.getNumero() + 1)
                .orElse(1001L);
    }

    private String estadoODefault(String estado, String valor) {
        return estado == null || estado.isBlank() ? valor : EstadoFactura.fromNombre(estado).name();
    }

    private Date aDate(LocalDate fecha) {
        return Date.from(fecha.atStartOfDay(ZoneId.systemDefault()).toInstant());
    }

    private Usuario usuarioSistema() {
        return usuarioRepository.findByUsuario("admin")
                .or(() -> usuarioRepository.findAll().stream().findFirst())
                .orElseThrow(() -> new IllegalStateException("No hay usuarios cargados para auditar la factura"));
    }

    private void auditarAlta(FacturaVenta factura) {
        Date ahora = new Date();
        Usuario usuario = usuarioSistema();
        factura.setFechaAlta(ahora);
        factura.setFechaModificacion(ahora);
        factura.setUsuarioCarga(usuario);
        factura.setUsuarioModificacion(usuario);
    }

    private void auditarModificacion(FacturaVenta factura) {
        factura.setFechaModificacion(new Date());
        factura.setUsuarioModificacion(usuarioSistema());
    }
}
