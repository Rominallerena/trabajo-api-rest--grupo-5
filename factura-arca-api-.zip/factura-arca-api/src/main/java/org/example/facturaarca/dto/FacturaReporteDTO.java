package org.example.facturaarca.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;

/**
 * Proyeccion plana para el reporte ejecutivo de ventas.
 *
 * <p>El {@code id} se agrego para el CRUD (PUT/DELETE por path variable) y el
 * {@code estado} para que el frontend sepa si una factura ya esta anulada.
 * El orden de los campos es el del constructor JPQL: no se puede reordenar
 * sin tocar la consulta.
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class FacturaReporteDTO {

    private Long id;
    private Long numeroFactura;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date fechaEmision;

    private String clienteDenominacion;
    private String condicionIva;
    private String puntoVentaDescripcion;
    private String estado;
    private double importeTotal;
    private long cantidadItems;
}
