package org.example.facturaarca.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class FacturaEstadoRequestDTO {

    @NotBlank(message = "estado es obligatorio")
    private String estado;

    private String observaciones;
}
