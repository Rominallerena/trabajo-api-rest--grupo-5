package org.example.facturaarca.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Renglon de alta/edicion. Solo viaja el id del articulo: el servicio busca
 * la entidad y calcula neto, IVA y subtotal.
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class FacturaDetalleRequestDTO {

    @NotNull(message = "articuloId es obligatorio")
    private Long articuloId;

    @NotNull
    @Positive(message = "La cantidad debe ser mayor a cero")
    private Double cantidad;

    /** Si no viene, se toma el precio de ListaPrecioArticulo. */
    private Double precioUnitario;

    private Double porcentajeBonificacion;
}
