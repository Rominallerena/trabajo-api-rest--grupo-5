package org.example.facturaarca.service.reporte;

import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.example.facturaarca.config.ReportesProperties;
import org.example.facturaarca.dto.FacturaReporteDTO;
import org.springframework.stereotype.Component;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;

/**
 * Reporte en hoja de calculo .xlsx con Apache POI. El enunciado permitia un
 * txt separado por tabulaciones; se genera un Excel real para que las columnas
 * numericas queden como numeros y se pueda totalizar desde la planilla.
 */
@Component
public class GeneradorReporteExcel implements GeneradorReporte {

    private static final String[] COLUMNAS = {
            "Nro. Factura", "Fecha Emision", "Cliente", "Condicion IVA",
            "Punto de Venta", "Cantidad Items", "Importe Total"
    };

    private final ReportesProperties propiedades;

    public GeneradorReporteExcel(ReportesProperties propiedades) {
        this.propiedades = propiedades;
    }

    @Override
    public String formato() {
        return "xlsx";
    }

    @Override
    public String contentType() {
        return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
    }

    @Override
    public byte[] generar(List<FacturaReporteDTO> filas) {
        try (Workbook libro = new XSSFWorkbook();
             ByteArrayOutputStream salida = new ByteArrayOutputStream()) {

            Sheet hoja = libro.createSheet("Facturas");

            CellStyle estiloTitulo = estiloTitulo(libro);
            CellStyle estiloEncabezado = estiloEncabezado(libro);
            CellStyle estiloFecha = estiloFecha(libro);
            CellStyle estiloImporte = estiloImporte(libro);
            CellStyle estiloTotal = estiloTotal(libro);

            Row filaTitulo = hoja.createRow(0);
            Cell celdaTitulo = filaTitulo.createCell(0);
            celdaTitulo.setCellValue(propiedades.getTitulo() + " - " + propiedades.getEmpresa());
            celdaTitulo.setCellStyle(estiloTitulo);
            hoja.addMergedRegion(new CellRangeAddress(0, 0, 0, COLUMNAS.length - 1));

            Row filaEncabezado = hoja.createRow(2);
            for (int i = 0; i < COLUMNAS.length; i++) {
                Cell celda = filaEncabezado.createCell(i);
                celda.setCellValue(COLUMNAS[i]);
                celda.setCellStyle(estiloEncabezado);
            }

            int numeroFila = 3;
            for (FacturaReporteDTO dto : filas) {
                Row fila = hoja.createRow(numeroFila++);

                fila.createCell(0).setCellValue(dto.getNumeroFactura() == null ? 0 : dto.getNumeroFactura());

                Cell celdaFecha = fila.createCell(1);
                if (dto.getFechaEmision() != null) {
                    celdaFecha.setCellValue(dto.getFechaEmision());
                    celdaFecha.setCellStyle(estiloFecha);
                }

                fila.createCell(2).setCellValue(dto.getClienteDenominacion());
                fila.createCell(3).setCellValue(dto.getCondicionIva());
                fila.createCell(4).setCellValue(dto.getPuntoVentaDescripcion());
                fila.createCell(5).setCellValue(dto.getCantidadItems());

                Cell celdaImporte = fila.createCell(6);
                celdaImporte.setCellValue(dto.getImporteTotal());
                celdaImporte.setCellStyle(estiloImporte);
            }

            if (!filas.isEmpty()) {
                Row filaTotales = hoja.createRow(numeroFila);
                Cell etiqueta = filaTotales.createCell(0);
                etiqueta.setCellValue("TOTALES");
                etiqueta.setCellStyle(estiloTotal);
                hoja.addMergedRegion(new CellRangeAddress(numeroFila, numeroFila, 0, 4));

                Cell totalItems = filaTotales.createCell(5);
                totalItems.setCellFormula("SUM(F4:F" + numeroFila + ")");
                totalItems.setCellStyle(estiloTotal);

                Cell totalImporte = filaTotales.createCell(6);
                totalImporte.setCellFormula("SUM(G4:G" + numeroFila + ")");
                totalImporte.setCellStyle(estiloTotal);
            }

            for (int i = 0; i < COLUMNAS.length; i++) {
                hoja.autoSizeColumn(i);
                hoja.setColumnWidth(i, Math.min(hoja.getColumnWidth(i) + 600, 12000));
            }
            hoja.createFreezePane(0, 3);

            libro.write(salida);
            return salida.toByteArray();
        } catch (IOException e) {
            throw new IllegalStateException("No se pudo generar el Excel del reporte", e);
        }
    }

    private CellStyle estiloTitulo(Workbook libro) {
        CellStyle estilo = libro.createCellStyle();
        var fuente = libro.createFont();
        fuente.setBold(true);
        fuente.setFontHeightInPoints((short) 14);
        estilo.setFont(fuente);
        estilo.setAlignment(HorizontalAlignment.CENTER);
        return estilo;
    }

    private CellStyle estiloEncabezado(Workbook libro) {
        CellStyle estilo = libro.createCellStyle();
        var fuente = libro.createFont();
        fuente.setBold(true);
        fuente.setColor(IndexedColors.WHITE.getIndex());
        estilo.setFont(fuente);
        estilo.setFillForegroundColor(IndexedColors.DARK_BLUE.getIndex());
        estilo.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        estilo.setAlignment(HorizontalAlignment.CENTER);
        estilo.setBorderBottom(BorderStyle.THIN);
        return estilo;
    }

    private CellStyle estiloFecha(Workbook libro) {
        CellStyle estilo = libro.createCellStyle();
        estilo.setDataFormat(libro.getCreationHelper()
                .createDataFormat()
                .getFormat(propiedades.getFormatoFecha()));
        return estilo;
    }

    private CellStyle estiloImporte(Workbook libro) {
        CellStyle estilo = libro.createCellStyle();
        estilo.setDataFormat(libro.getCreationHelper()
                .createDataFormat()
                .getFormat("#,##0.00"));
        return estilo;
    }

    private CellStyle estiloTotal(Workbook libro) {
        CellStyle estilo = libro.createCellStyle();
        var fuente = libro.createFont();
        fuente.setBold(true);
        estilo.setFont(fuente);
        estilo.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
        estilo.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        estilo.setBorderTop(BorderStyle.THIN);
        estilo.setDataFormat(libro.getCreationHelper()
                .createDataFormat()
                .getFormat("#,##0.00"));
        return estilo;
    }
}
