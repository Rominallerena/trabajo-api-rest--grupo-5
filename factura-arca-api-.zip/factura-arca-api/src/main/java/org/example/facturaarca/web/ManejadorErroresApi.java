package org.example.facturaarca.web;

import org.example.facturaarca.service.FormatoReporteNoSoportadoException;
import org.example.facturaarca.service.RecursoNoEncontradoException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;

import java.util.List;

/**
 * Traduce las excepciones de la API a respuestas JSON con un codigo HTTP
 * razonable, en lugar del 500 generico de Spring Boot.
 *
 * <p>Un solo punto de manejo para toda la aplicacion: el frontend siempre
 * recibe el mismo cuerpo {@code {status, mensaje, fecha, detalles}} y puede
 * mostrarlo sin casos especiales.
 */
@RestControllerAdvice
public class ManejadorErroresApi {

    private static final Logger log = LoggerFactory.getLogger(ManejadorErroresApi.class);

    /** 404: la factura, el cliente o el articulo no existen. */
    @ExceptionHandler(RecursoNoEncontradoException.class)
    public ResponseEntity<ErrorResponse> recursoNoEncontrado(RecursoNoEncontradoException e) {
        return responder(HttpStatus.NOT_FOUND, "Recurso no encontrado", e.getMessage());
    }

    /** 400: el cuerpo del POST/PUT no cumple las validaciones de Bean Validation. */
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ErrorResponse> validacionFallida(MethodArgumentNotValidException e) {
        List<String> detalles = e.getBindingResult().getFieldErrors().stream()
                .map(error -> error.getField() + ": " + error.getDefaultMessage())
                .toList();

        // Solo los errores por campo: el mensaje de la excepcion de Spring
        // repite los mismos errores en un texto largo y sin formato.
        return responder(HttpStatus.BAD_REQUEST, "Datos invalidos", null, detalles);
    }

    /** 400: el JSON no se pudo deserializar (campo faltante, tipo incorrecto...). */
    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<ErrorResponse> cuerpoInvalido(HttpMessageNotReadableException e) {
        return responder(HttpStatus.BAD_REQUEST, "Cuerpo de la peticion invalido",
                "No se pudo leer el JSON enviado.");
    }

    /** 400: argumento de negocio invalido (estado desconocido, factura anulada...). */
    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<ErrorResponse> argumentoInvalido(IllegalArgumentException e) {
        return responder(HttpStatus.BAD_REQUEST, "Argumento invalido", e.getMessage());
    }

    /** 400: formato de reporte que no existe (pdf, xlsx, docx...). */
    @ExceptionHandler(FormatoReporteNoSoportadoException.class)
    public ResponseEntity<ErrorResponse> formatoNoSoportado(FormatoReporteNoSoportadoException e) {
        return responder(HttpStatus.BAD_REQUEST, "Formato de reporte invalido", e.getMessage());
    }

    /** 400: un parametro de query con un valor imposible (por ejemplo una fecha). */
    @ExceptionHandler(MethodArgumentTypeMismatchException.class)
    public ResponseEntity<ErrorResponse> parametroInvalido(MethodArgumentTypeMismatchException e) {
        String detalle = "El parametro '" + e.getName() + "' no tiene un valor valido: '" + e.getValue() + "'."
                + ("fechaDesde".equals(e.getName()) || "fechaHasta".equals(e.getName())
                ? " Se espera el formato yyyy-MM-dd." : "");

        return responder(HttpStatus.BAD_REQUEST, "Parametro invalido", detalle);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorResponse> errorInesperado(Exception e) throws Exception {
        // Las excepciones propias de Spring MVC (404 de ruta, 405, 415...) ya
        // traen su status: si las absorbieramos aca se irian todas como 500.
        // El nombre completo es necesario porque esta clase tambien define
        // un ErrorResponse propio.
        if (e instanceof org.springframework.web.ErrorResponse) {
            throw e;
        }
        log.error("Error no controlado atendiendo la peticion", e);
        return responder(HttpStatus.INTERNAL_SERVER_ERROR, "Error interno",
                "No se pudo completar la operacion.");
    }

    private ResponseEntity<ErrorResponse> responder(HttpStatus estado, String titulo, String detalle) {
        return responder(estado, titulo, detalle, List.of());
    }

    private ResponseEntity<ErrorResponse> responder(HttpStatus estado, String titulo, String detalle,
                                                    List<String> detalles) {
        ErrorResponse cuerpo = new ErrorResponse(estado, titulo, detalles);
        cuerpo.setMensaje(titulo);
        if (detalle != null && !detalle.isBlank()) {
            cuerpo.conDetalle(detalle);
        }
        return ResponseEntity.status(estado).body(cuerpo);
    }
}
