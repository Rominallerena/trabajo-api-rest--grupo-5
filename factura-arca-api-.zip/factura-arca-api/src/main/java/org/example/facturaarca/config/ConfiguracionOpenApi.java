package org.example.facturaarca.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Metadatos de la documentacion OpenAPI (la cabecera de Swagger UI).
 *
 * <p>Se definen con un bean {@link OpenAPI} y no con las propiedades
 * {@code springdoc.info.*} porque esas no las lee springdoc: la cabecera
 * terminaba mostrando los valores por defecto.
 */
@Configuration
public class ConfiguracionOpenApi {

    @Bean
    public OpenAPI facturaArcaApi() {
        return new OpenAPI()
                .info(new Info()
                        .title("API de Facturas de Venta")
                        .description("CRUD de facturas de venta y reportes de ventas (TP de API REST con Spring Boot)")
                        .version("1.0.0")
                        .contact(new Contact()
                                .name("FacturaArca")
                                .email("facturaarca@utn.edu.ar"))
                        .license(new License()
                                .name("Uso academico")));
    }
}
