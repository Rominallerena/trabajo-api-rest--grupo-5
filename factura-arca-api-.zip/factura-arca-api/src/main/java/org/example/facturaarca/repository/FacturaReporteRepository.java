package org.example.facturaarca.repository;

import jakarta.persistence.EntityManager;
import jakarta.persistence.TemporalType;
import jakarta.persistence.TypedQuery;
import org.example.facturaarca.dto.FacturaFiltro;
import org.example.facturaarca.dto.FacturaReporteDTO;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Acceso a datos del reporte de ventas.
 *
 * <p>Estereotipo {@code @Repository}: ademas de registrar el bean, Spring
 * traduce las excepciones de persistencia a su jerarquia
 * {@code DataAccessException}.
 *
 * <p>La consulta proyecta directamente sobre {@link FacturaReporteDTO} con una
 * expresion de constructor, de manera que Hibernate nunca llega a materializar
 * las entidades completas ni sus asociaciones LAZY.
 */
@Repository
public class FacturaReporteRepository {

    private static final String SELECT_DTO =
            "SELECT new org.example.facturaarca.dto.FacturaReporteDTO("
                    + "  f.id, "
                    + "  f.numero, "
                    + "  f.fechaEmision, "
                    + "  COALESCE(c.denominacion, 'Consumidor Final'), "
                    + "  ci.denominacion, "
                    + "  pv.descripcion, "
                    + "  f.estado, "
                    + "  f.importeTotal, "
                    + "  COUNT(d)"
                    + ") "
                    + "FROM FacturaVenta f "
                    + "LEFT JOIN f.cliente c "
                    + "JOIN f.condicionIva ci "
                    + "JOIN f.puntoVenta pv "
                    + "JOIN f.detalles d ";

    private static final String GROUP_BY =
            "GROUP BY f.id, f.numero, f.fechaEmision, c.denominacion, "
                    + "ci.denominacion, pv.descripcion, f.estado, f.importeTotal "
                    + "ORDER BY f.numero";

    private final EntityManager entityManager;

    public FacturaReporteRepository(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    /** Reporte completo, sin filtros (consigna de la Parte 2). */
    public List<FacturaReporteDTO> listarReporteCompleto() {
        return entityManager
                .createQuery(SELECT_DTO + GROUP_BY, FacturaReporteDTO.class)
                .getResultList();
    }

    /**
     * Busqueda dinamica: cada filtro no nulo agrega su propio AND y su
     * parametro nombrado. El {@code WHERE 1=1} evita tener que decidir si el
     * proximo fragmento empieza con WHERE o con AND.
     */
    public List<FacturaReporteDTO> buscarFacturasFiltradas(FacturaFiltro filtro) {
        StringBuilder jpql = new StringBuilder(SELECT_DTO).append("WHERE 1=1 ");
        Map<String, Object> params = new HashMap<>();

        if (filtro.getNumeroFactura() != null) {
            jpql.append("AND f.numero = :numeroFactura ");
            params.put("numeroFactura", filtro.getNumeroFactura());
        }
        if (filtro.getClienteDenominacion() != null) {
            // Se filtra contra la denominacion del cliente del modelo y no
            // contra un id: es el mismo criterio que muestra el reporte, donde
            // una factura sin cliente aparece como "Consumidor Final".
            jpql.append("AND LOWER(COALESCE(c.denominacion, 'Consumidor Final')) "
                    + "LIKE LOWER(:clienteDenominacion) ");
            params.put("clienteDenominacion", "%" + filtro.getClienteDenominacion() + "%");
        }
        if (filtro.getCondicionIva() != null) {
            jpql.append("AND LOWER(ci.denominacion) LIKE LOWER(:condicionIva) ");
            params.put("condicionIva", "%" + filtro.getCondicionIva() + "%");
        }
        if (filtro.getFechaDesde() != null) {
            jpql.append("AND f.fechaEmision >= :fechaDesde ");
            params.put("fechaDesde", filtro.getFechaDesde());
        }
        if (filtro.getFechaHasta() != null) {
            jpql.append("AND f.fechaEmision <= :fechaHasta ");
            params.put("fechaHasta", filtro.getFechaHasta());
        }
        if (filtro.getEstado() != null) {
            jpql.append("AND f.estado = :estado ");
            params.put("estado", filtro.getEstado().toUpperCase());
        }
        if (filtro.getMontoMinimo() != null) {
            jpql.append("AND f.importeTotal >= :montoMinimo ");
            params.put("montoMinimo", filtro.getMontoMinimo());
        }

        jpql.append(GROUP_BY);

        TypedQuery<FacturaReporteDTO> query =
                entityManager.createQuery(jpql.toString(), FacturaReporteDTO.class);
        params.forEach((nombre, valor) -> {
            if (valor instanceof Date fecha) {
                // Sin el TemporalType explicito, un java.util.Date se bindea como
                // DATE y se pierde la hora: una factura del dia de fechaHasta a
                // las 16:40 quedaria afuera del <=.
                query.setParameter(nombre, fecha, TemporalType.TIMESTAMP);
            } else {
                query.setParameter(nombre, valor);
            }
        });
        return query.getResultList();
    }

    public FacturaReporteDTO buscarReportePorId(Long id) {
        List<FacturaReporteDTO> filas = entityManager
                .createQuery(SELECT_DTO + "WHERE f.id = :id " + GROUP_BY, FacturaReporteDTO.class)
                .setParameter("id", id)
                .getResultList();
        return filas.isEmpty() ? null : filas.get(0);
    }
}
