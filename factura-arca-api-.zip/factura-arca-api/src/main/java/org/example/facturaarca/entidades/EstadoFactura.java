package org.example.facturaarca.entidades;

/**
 * Estados posibles de una factura de venta.
 *
 * <p>La entidad guarda el estado como texto (columna {@code estado}), pero
 * este enum es la unica fuente de verdad de los valores validos: asi el
 * servicio puede rechazar un estado desconocido con un 400 claro en vez de
 * guardar cualquier texto en la base.
 */
public enum EstadoFactura {

    EMITIDA,
    AUTORIZADA,
    ANULADA,
    RECHAZADA;

    /**
     * Convierte el texto que viaja en el JSON al estado correspondiente.
     *
     * @throws IllegalArgumentException si el texto no es uno de los estados validos
     */
    public static EstadoFactura fromNombre(String nombre) {
        if (nombre == null || nombre.isBlank()) {
            throw new IllegalArgumentException("El estado de la factura es obligatorio");
        }
        try {
            return valueOf(nombre.trim().toUpperCase());
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Estado de factura invalido: '" + nombre
                    + "'. Los estados validos son: " + valores());
        }
    }

    public static String valores() {
        StringBuilder texto = new StringBuilder();
        for (EstadoFactura estado : values()) {
            if (texto.length() > 0) {
                texto.append(", ");
            }
            texto.append(estado.name());
        }
        return texto.toString();
    }
}
