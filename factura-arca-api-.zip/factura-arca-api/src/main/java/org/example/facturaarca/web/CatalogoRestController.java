package org.example.facturaarca.web;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.example.facturaarca.dto.CatalogoItemDTO;
import org.example.facturaarca.service.CatalogoService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

/**
 * Catalogos que alimentan los desplegables del formulario de alta.
 *
 * <p>No son parte del CRUD de facturas, pero el frontend los necesita para
 * elegir cliente, condicion de IVA, punto de venta, moneda y articulos sin
 * conocer el modelo de datos.
 */
@RestController
@RequestMapping("/api/catalogos")
@Tag(name = "Catalogos", description = "Listas de apoyo para el formulario de facturas")
public class CatalogoRestController {

    private final CatalogoService catalogoService;

    public CatalogoRestController(CatalogoService catalogoService) {
        this.catalogoService = catalogoService;
    }

    @Operation(summary = "Todos los catalogos en una sola llamada",
            description = "Devuelve articulos, clientes, condiciones de IVA, puntos de venta y monedas.")
    @GetMapping
    public Map<String, List<CatalogoItemDTO>> todos() {
        return catalogoService.todos();
    }

    @Operation(summary = "Articulos con precio de venta")
    @GetMapping("/articulos")
    public List<CatalogoItemDTO> articulos() {
        return catalogoService.articulos();
    }

    @Operation(summary = "Clientes")
    @GetMapping("/clientes")
    public List<CatalogoItemDTO> clientes() {
        return catalogoService.clientes();
    }

    @Operation(summary = "Condiciones de IVA")
    @GetMapping("/condiciones-iva")
    public List<CatalogoItemDTO> condicionesIva() {
        return catalogoService.condicionesIva();
    }

    @Operation(summary = "Puntos de venta")
    @GetMapping("/puntos-venta")
    public List<CatalogoItemDTO> puntosVenta() {
        return catalogoService.puntosVenta();
    }

    @Operation(summary = "Monedas")
    @GetMapping("/monedas")
    public List<CatalogoItemDTO> monedas() {
        return catalogoService.monedas();
    }
}
