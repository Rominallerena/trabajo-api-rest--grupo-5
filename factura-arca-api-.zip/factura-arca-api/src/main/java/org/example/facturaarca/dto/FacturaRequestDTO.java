package org.example.facturaarca.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * Contrato de entrada de POST y PUT. Las relaciones viajan como IDs, nunca
 * como entidades anidadas, para no acoplar el JSON al modelo JPA.
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class FacturaRequestDTO {

    private Long numero;

    @NotNull(message = "fechaEmision es obligatoria")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate fechaEmision;

    /** Nulo = Consumidor Final. */
    private Long clienteId;

    @NotNull(message = "condicionIvaId es obligatorio")
    private Long condicionIvaId;

    @NotNull(message = "puntoVentaId es obligatorio")
    private Long puntoVentaId;

    @NotNull(message = "tipoMonedaId es obligatorio")
    private Long tipoMonedaId;

    private String estado;
    private String observaciones;

    @Valid
    @NotEmpty(message = "La factura debe tener al menos un detalle")
    private List<FacturaDetalleRequestDTO> detalles = new ArrayList<>();
}
