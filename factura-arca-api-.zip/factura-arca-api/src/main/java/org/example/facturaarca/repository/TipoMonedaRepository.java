package org.example.facturaarca.repository;

import org.example.facturaarca.entidades.TipoMoneda;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TipoMonedaRepository extends JpaRepository<TipoMoneda, Long> {
}
