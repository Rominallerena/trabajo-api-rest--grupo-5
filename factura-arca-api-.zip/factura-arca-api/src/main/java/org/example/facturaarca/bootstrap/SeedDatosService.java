package org.example.facturaarca.bootstrap;

import jakarta.persistence.EntityManager;
import org.example.facturaarca.entidades.Articulo;
import org.example.facturaarca.entidades.AuditoriaApp;
import org.example.facturaarca.entidades.Cliente;
import org.example.facturaarca.entidades.CondicionIva;
import org.example.facturaarca.entidades.Contacto;
import org.example.facturaarca.entidades.Domicilio;
import org.example.facturaarca.entidades.FacturaVenta;
import org.example.facturaarca.entidades.FacturaVentaDetalle;
import org.example.facturaarca.entidades.ListaPrecio;
import org.example.facturaarca.entidades.ListaPrecioArticulo;
import org.example.facturaarca.entidades.Marca;
import org.example.facturaarca.entidades.PuntoVenta;
import org.example.facturaarca.entidades.Rubro;
import org.example.facturaarca.entidades.TipoMoneda;
import org.example.facturaarca.entidades.Usuario;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;

/**
 * Juego de datos de prueba.
 *
 * <p>Esta armado para que el reporte no quede trivial: hay facturas en los
 * cuatro estados, clientes distintos, tres puntos de venta, facturas de uno y
 * de varios items, e importes repartidos en rangos bien separados.
 *
 * <p>Todas las entidades se arman con los builders que genera Lombok
 * ({@code @SuperBuilder}), que es lo que reemplaza a los constructores
 * manuales de la version anterior del modelo.
 */
@Service
public class SeedDatosService {

    private final EntityManager em;

    public SeedDatosService(EntityManager em) {
        this.em = em;
    }

    @Transactional(readOnly = true)
    public boolean hayDatos() {
        Long cantidad = em.createQuery("SELECT COUNT(f) FROM FacturaVenta f", Long.class).getSingleResult();
        return cantidad != null && cantidad > 0;
    }

    @Transactional
    public int sembrar() {
        Date alta = fecha("2026-01-02T09:00");

        Usuario admin = persistir(Usuario.builder()
                .usuario("admin").clave("clave123").nombre("Lautaro").apellido("Villarroel").build());
        Usuario jperez = persistir(Usuario.builder()
                .usuario("jperez").clave("clave123").nombre("Juan").apellido("Perez").build());
        Usuario mgomez = persistir(Usuario.builder()
                .usuario("mgomez").clave("clave123").nombre("Maria").apellido("Gomez").build());

        Rubro electronica = persistir(auditar(Rubro.builder().codigo(10).denominacion("Electronica").build(), admin, alta));
        Rubro informatica = persistir(auditar(Rubro.builder().codigo(20).denominacion("Informatica").build(), admin, alta));
        Rubro libreria = persistir(auditar(Rubro.builder().codigo(30).denominacion("Libreria").build(), admin, alta));

        Marca logitech = persistir(auditar(Marca.builder().codigo(100).denominacion("Logitech").build(), admin, alta));
        Marca samsung = persistir(auditar(Marca.builder().codigo(200).denominacion("Samsung").build(), admin, alta));
        Marca noblex = persistir(auditar(Marca.builder().codigo(300).denominacion("Noblex").build(), admin, alta));

        Articulo mouse = articulo(admin, alta, "MOU-001", "Mouse inalambrico", informatica, logitech);
        Articulo teclado = articulo(admin, alta, "TEC-001", "Teclado mecanico", informatica, logitech);
        Articulo auriculares = articulo(admin, alta, "AUR-001", "Auriculares Bluetooth", electronica, logitech);
        Articulo tv = articulo(admin, alta, "TV-055", "Smart TV 55 pulgadas", electronica, samsung);
        Articulo celular = articulo(admin, alta, "CEL-128", "Celular 128GB", electronica, samsung);
        Articulo heladera = articulo(admin, alta, "HEL-300", "Heladera 300L", electronica, noblex);
        Articulo resma = articulo(admin, alta, "RES-001", "Resma A4", libreria, null);

        PuntoVenta pvCentro = persistir(auditar(PuntoVenta.builder()
                .numero(1).descripcion("Sucursal Centro").tipoEmision("CAE")
                .domicilioComercial("San Martin 450").build(), admin, alta));
        PuntoVenta pvNorte = persistir(auditar(PuntoVenta.builder()
                .numero(2).descripcion("Sucursal Norte").tipoEmision("CAE")
                .domicilioComercial("Av. Colon 2100").build(), admin, alta));
        PuntoVenta pvOnline = persistir(auditar(PuntoVenta.builder()
                .numero(5).descripcion("Sucursal Online").tipoEmision("CAE")
                .domicilioComercial("Sin domicilio fisico").build(), admin, alta));

        CondicionIva responsable = persistir(auditar(CondicionIva.builder()
                .codigoAfip(1).denominacion("IVA Responsable Inscripto").build(), admin, alta));
        CondicionIva monotributo = persistir(auditar(CondicionIva.builder()
                .codigoAfip(6).denominacion("Responsable Monotributo").build(), admin, alta));
        CondicionIva consumidor = persistir(auditar(CondicionIva.builder()
                .codigoAfip(5).denominacion("Consumidor Final").build(), admin, alta));

        TipoMoneda peso = persistir(auditar(TipoMoneda.builder()
                .codigoAfip("PES").denominacion("Peso Argentino").simbolo("$").build(), admin, alta));

        ListaPrecio minorista = persistir(auditar(ListaPrecio.builder()
                .codigo("LP-MIN").denominacion("Lista Minorista").build(), admin, alta));

        ListaPrecioArticulo pMouse = precio(admin, alta, minorista, mouse, 8500);
        ListaPrecioArticulo pTeclado = precio(admin, alta, minorista, teclado, 24500);
        ListaPrecioArticulo pAuriculares = precio(admin, alta, minorista, auriculares, 15000);
        ListaPrecioArticulo pTv = precio(admin, alta, minorista, tv, 620000);
        ListaPrecioArticulo pCelular = precio(admin, alta, minorista, celular, 450000);
        ListaPrecioArticulo pHeladera = precio(admin, alta, minorista, heladera, 780000);
        ListaPrecioArticulo pResma = precio(admin, alta, minorista, resma, 6500);

        Cliente delSur = cliente(admin, alta, "20-30111222-3", "Distribuidora Del Sur SA", "ventas@delsur.com");
        Cliente norte = cliente(admin, alta, "27-28999111-4", "Comercial Norte SRL", "info@comnorte.com");
        Cliente pampa = cliente(admin, alta, "20-33444555-6", "Tecno Pampa SA", "compras@tecnopampa.com");
        Cliente servicios = cliente(admin, alta, "33-70999888-1", "Servicios Integrales SA", "admin@siasa.com");

        int facturas = 0;
        // Sin cliente: el COALESCE del reporte tiene que mostrar "Consumidor Final".
        facturas += factura(admin, 1001, "2026-01-15T10:30", "EMITIDA", null, pvCentro, responsable, peso,
                new Linea(pMouse, 2), new Linea(pTeclado, 1));
        facturas += factura(admin, 1002, "2026-01-28T11:05", "AUTORIZADA", norte, pvCentro, responsable, peso,
                new Linea(pTv, 1));
        facturas += factura(admin, 1003, "2026-02-10T09:15", "EMITIDA", pampa, pvNorte, monotributo, peso,
                new Linea(pResma, 4));
        facturas += factura(admin, 1004, "2026-02-22T16:40", "ANULADA", delSur, pvNorte, responsable, peso,
                new Linea(pAuriculares, 2));
        facturas += factura(admin, 1005, "2026-03-05T12:20", "EMITIDA", null, pvCentro, consumidor, peso,
                new Linea(pCelular, 1));
        facturas += factura(jperez, 1006, "2026-03-18T15:00", "AUTORIZADA", delSur, pvOnline, monotributo, peso,
                new Linea(pMouse, 1), new Linea(pResma, 2), new Linea(pTeclado, 1));
        facturas += factura(jperez, 1007, "2026-04-02T10:10", "RECHAZADA", servicios, pvOnline, responsable, peso,
                new Linea(pTeclado, 1));
        facturas += factura(jperez, 1008, "2026-04-14T13:45", "EMITIDA", delSur, pvNorte, responsable, peso,
                new Linea(pHeladera, 1));
        facturas += factura(jperez, 1009, "2026-05-03T09:50", "EMITIDA", norte, pvCentro, responsable, peso,
                new Linea(pAuriculares, 1), new Linea(pMouse, 2));
        facturas += factura(mgomez, 1010, "2026-05-20T17:25", "AUTORIZADA", pampa, pvCentro, responsable, peso,
                new Linea(pTv, 2));
        facturas += factura(mgomez, 1011, "2026-06-08T11:35", "EMITIDA", null, pvOnline, consumidor, peso,
                new Linea(pResma, 1));
        facturas += factura(mgomez, 1012, "2026-06-25T14:05", "ANULADA", servicios, pvNorte, monotributo, peso,
                new Linea(pMouse, 3));

        return facturas;
    }

    // ------------------------------------------------------------------
    // Helpers
    // ------------------------------------------------------------------

    /** Par (precio, cantidad) para no repetir el armado de cada detalle. */
    private record Linea(ListaPrecioArticulo precio, double cantidad) {
    }

    private int factura(Usuario usuario, long numero, String fechaEmision, String estado,
                        Cliente cliente, PuntoVenta puntoVenta, CondicionIva condicionIva,
                        TipoMoneda tipoMoneda, Linea... lineas) {
        Date emision = fecha(fechaEmision);

        FacturaVenta factura = FacturaVenta.builder()
                .numero(numero)
                .fechaEmision(emision)
                .estado(estado)
                .cliente(cliente)
                .puntoVenta(puntoVenta)
                .condicionIva(condicionIva)
                .tipoMoneda(tipoMoneda)
                .build();

        if ("AUTORIZADA".equals(estado)) {
            factura.setCae("741258963" + numero);
            factura.setResultadoAfip("A");
        } else if ("RECHAZADA".equals(estado)) {
            factura.setResultadoAfip("R");
            factura.setMotivoRechazo("CUIT del receptor inexistente");
        } else if ("ANULADA".equals(estado)) {
            factura.setFechaAnulacion(emision);
        }

        double total = 0;
        for (Linea linea : lineas) {
            double neto = linea.cantidad() * linea.precio().getPrecioVenta();
            factura.addDetalle(FacturaVentaDetalle.builder()
                    .listaPrecioArticulo(linea.precio())
                    .descripcion(linea.precio().getArticulo().getDenominacion())
                    .cantidad(linea.cantidad())
                    .precioUnitario(linea.precio().getPrecioVenta())
                    .importeNeto(neto)
                    .importeIva(neto * 0.21)
                    .importeSubtotal(neto)
                    .build());
            total += neto;
        }

        factura.setImporteTotal(total);
        if ("AUTORIZADA".equals(estado)) {
            factura.setImporteCobrado(total);
        } else {
            factura.setImporteSaldo(total);
        }

        auditar(factura, usuario, emision);
        // Un solo persist: los detalles entran por CascadeType.ALL.
        em.persist(factura);
        return 1;
    }

    private Articulo articulo(Usuario u, Date f, String codigo, String denominacion, Rubro rubro, Marca marca) {
        return persistir(auditar(Articulo.builder()
                .codigo(codigo).denominacion(denominacion).rubro(rubro).marca(marca).build(), u, f));
    }

    private ListaPrecioArticulo precio(Usuario u, Date f, ListaPrecio lista, Articulo articulo, double precioVenta) {
        return persistir(auditar(ListaPrecioArticulo.builder()
                .listaPrecio(lista).articulo(articulo).precioVenta(precioVenta).build(), u, f));
    }

    private Cliente cliente(Usuario u, Date f, String cuit, String denominacion, String email) {
        return persistir(auditar(Cliente.builder()
                .cuitCuil(cuit)
                .denominacion(denominacion)
                .contacto(Contacto.builder().email(email).telefono("3514000000").celular("3514000000").build())
                .domicilio(Domicilio.builder().nombreCalle("Belgrano").numeroCalle("1200").build())
                .build(), u, f));
    }

    private <T extends AuditoriaApp> T auditar(T entidad, Usuario usuario, Date fecha) {
        entidad.setFechaAlta(fecha);
        entidad.setFechaModificacion(fecha);
        entidad.setUsuarioCarga(usuario);
        entidad.setUsuarioModificacion(usuario);
        return entidad;
    }

    private <T> T persistir(T entidad) {
        em.persist(entidad);
        return entidad;
    }

    private static Date fecha(String iso) {
        return Date.from(LocalDateTime.parse(iso).atZone(ZoneId.systemDefault()).toInstant());
    }
}
