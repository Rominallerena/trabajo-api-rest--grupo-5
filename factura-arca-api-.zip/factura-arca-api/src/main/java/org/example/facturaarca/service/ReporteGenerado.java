package org.example.facturaarca.service;

/** Archivo de reporte ya renderizado, listo para escribir o para devolver por HTTP. */
public record ReporteGenerado(String nombreArchivo, String contentType, byte[] contenido) {
}
