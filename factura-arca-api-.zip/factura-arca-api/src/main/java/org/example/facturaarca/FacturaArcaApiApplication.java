package org.example.facturaarca;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;

/**
 * Punto de entrada.
 *
 * <p>{@code @SpringBootApplication} combina {@code @Configuration},
 * {@code @EnableAutoConfiguration} y {@code @ComponentScan}, por eso alcanza
 * con que el resto de los beans cuelguen de este paquete hacia abajo.
 */
@SpringBootApplication
@ConfigurationPropertiesScan
public class FacturaArcaApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(FacturaArcaApiApplication.class, args);
    }
}
