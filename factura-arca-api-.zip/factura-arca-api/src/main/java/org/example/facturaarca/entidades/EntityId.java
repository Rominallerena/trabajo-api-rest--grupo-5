package org.example.facturaarca.entidades;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.MappedSuperclass;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

/**
 * Raiz de la jerarquia: aporta el identificador generado por la base.
 *
 * <p>Se usa {@link SuperBuilder} en lugar de {@code @Builder} porque el builder
 * tiene que poder cargar tambien los campos heredados. Con {@code @Builder} a
 * secas, cada subclase solo podria setear sus propios atributos.
 */
@MappedSuperclass
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
@EqualsAndHashCode
@ToString
public abstract class EntityId {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    protected Long id;
}
