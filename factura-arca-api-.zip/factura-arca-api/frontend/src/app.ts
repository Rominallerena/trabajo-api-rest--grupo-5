/**
 * Logica de la interfaz del CRUD de facturas.
 *
 * <p>Acá vive todo lo que NO es una llamada HTTP: leer el DOM, guardar los
 * renglones del formulario en memoria, dibujar las tablas, abrir los modales
 * y enganchar los eventos. Las llamadas al backend salen de `FacturaService`.
 */

import {
    CatalogosDTO,
    CatalogoItemDTO,
    FacturaDetalleRequestDTO,
    FacturaFiltrosDTO,
    FacturaReporteDTO,
    FacturaRequestDTO,
    crearDetalleVacio,
    hoy
} from './models/factura.dto.js';
import { ApiError, facturaService } from './services/FacturaService.js';

/** Opcion de un modal de seleccion. */
interface OpcionSelector {
    id: number;
    etiqueta: string;
}

/** Estado de la pantalla: lo que vive en memoria mientras se usa la pagina. */
interface EstadoApp {
    catalogos: CatalogosDTO | null;
    /** Renglones del formulario de alta, todavia no guardados. */
    detalles: FacturaDetalleRequestDTO[];
    /** Ultimo listado recibido del backend. */
    facturas: FacturaReporteDTO[];
    /** Cliente elegido en el modal (null = Consumidor Final). */
    clienteId: number | null;
}

const estado: EstadoApp = {
    catalogos: null,
    detalles: [],
    facturas: [],
    clienteId: null
};

/** Opciones y callback del modal de seleccion que esta abierto. */
let opcionesSelector: OpcionSelector[] = [];
let alElegirSelector: ((opcion: OpcionSelector) => void) | null = null;

// ---------------------------------------------------------------------------
// Utilidades de DOM
// ---------------------------------------------------------------------------

function elemento<T extends HTMLElement>(id: string): T {
    const encontrado = document.getElementById(id);
    if (!encontrado) {
        throw new Error(`Falta el elemento #${id} en el HTML`);
    }
    return encontrado as T;
}

function valorDe(id: string): string {
    return elemento<HTMLInputElement | HTMLSelectElement>(id).value.trim();
}

function numeroDe(id: string): number | undefined {
    const texto = valorDe(id);
    if (texto === '') {
        return undefined;
    }
    const parsed = Number(texto);
    return Number.isFinite(parsed) ? parsed : undefined;
}

/** Escribe un mensaje en el area de avisos de la pagina. */
function avisar(mensaje: string, tipo: 'ok' | 'error' | 'info' = 'info'): void {
    const area = elemento('mensaje');
    area.textContent = mensaje;
    area.className = `mensaje ${tipo}`;
}

function formatearMoneda(valor: number): string {
    return new Intl.NumberFormat('es-AR', {
        style: 'currency',
        currency: 'ARS',
        minimumFractionDigits: 2
    }).format(valor);
}

/** Precio de lista de un articulo, segun los catalogos ya cargados. */
function precioDeArticulo(articuloId: number): number {
    const articulo = estado.catalogos?.articulos.find((item) => item.id === articuloId);
    return articulo?.precio ?? 0;
}

/** Nombre del articulo elegido en un renglon. */
function nombreDeArticulo(articuloId: number): string {
    const articulo = estado.catalogos?.articulos.find((item) => item.id === articuloId);
    return articulo?.denominacion ?? '';
}

// ---------------------------------------------------------------------------
// Seccion 1: formulario de busqueda
// ---------------------------------------------------------------------------

/**
 * Arma los filtros del listado.
 *
 * <p>Los cinco filtros salen del modelo de datos: numero de comprobante,
 * denominacion del cliente, denominacion de la condicion de IVA y rango de
 * fechas de emision. No se inventa ningun campo que la API no tenga.
 */
function armarFiltros(): FacturaFiltrosDTO {
    const filtros: FacturaFiltrosDTO = {};

    const numeroFactura = numeroDe('filtro-numero');
    if (numeroFactura !== undefined) {
        filtros.numeroFactura = numeroFactura;
    }

    const clienteDenominacion = valorDe('filtro-cliente');
    if (clienteDenominacion) {
        filtros.clienteDenominacion = clienteDenominacion;
    }

    const condicionIva = valorDe('filtro-condicion-iva');
    if (condicionIva) {
        filtros.condicionIva = condicionIva;
    }

    const fechaDesde = valorDe('filtro-fecha-desde');
    if (fechaDesde) {
        filtros.fechaDesde = fechaDesde;
    }

    const fechaHasta = valorDe('filtro-fecha-hasta');
    if (fechaHasta) {
        filtros.fechaHasta = fechaHasta;
    }

    return filtros;
}

async function buscarFacturas(): Promise<void> {
    try {
        estado.facturas = await facturaService.obtenerFacturas(armarFiltros());
        dibujarFacturas();
        avisar(`Se encontraron ${estado.facturas.length} facturas.`, 'ok');
    } catch (error) {
        avisar(mensajeDeError(error), 'error');
    }
}

function limpiarFiltros(): void {
    elemento<HTMLInputElement>('filtro-numero').value = '';
    elemento<HTMLInputElement>('filtro-cliente').value = '';
    elemento<HTMLSelectElement>('filtro-condicion-iva').value = '';
    elemento<HTMLInputElement>('filtro-fecha-desde').value = '';
    elemento<HTMLInputElement>('filtro-fecha-hasta').value = '';
    void buscarFacturas();
}

// ---------------------------------------------------------------------------
// Seccion 2: alta de factura (en un modal)
// ---------------------------------------------------------------------------

function abrirAlta(): void {
    limpiarFormulario();
    const modal = elemento<HTMLDialogElement>('modal-factura');
    if (!modal.open) {
        modal.showModal();
    }
}

function cerrarAlta(): void {
    elemento<HTMLDialogElement>('modal-factura').close();
}

/** Agrega un renglon vacio al estado en memoria y redibuja la tabla. */
function agregarDetalle(): void {
    estado.detalles.push(crearDetalleVacio());
    dibujarDetalles();
}

/** Saca un renglon del estado en memoria y redibuja la tabla. */
function quitarDetalle(indice: number): void {
    estado.detalles.splice(indice, 1);
    if (estado.detalles.length === 0) {
        estado.detalles.push(crearDetalleVacio());
    }
    dibujarDetalles();
}

/**
 * Abre el modal de articulos y carga el renglon elegido.
 *
 * <p>El precio se toma del catalogo, que es el mismo precio de lista que usa
 * el backend cuando el renglon no manda `precioUnitario`.
 */
function elegirArticulo(indice: number): void {
    const detalle = estado.detalles[indice];
    if (!detalle) {
        return;
    }

    abrirSelector('Elegir articulo', articulosComoOpciones(), (opcion) => {
        detalle.articuloId = opcion.id;
        detalle.precioUnitario = precioDeArticulo(opcion.id);
        dibujarDetalles();
    });
}

/** Abre el modal de clientes y carga el cliente de la cabecera. */
function elegirCliente(): void {
    const opciones: OpcionSelector[] = [
        { id: 0, etiqueta: 'Consumidor Final' },
        ...(estado.catalogos?.clientes ?? []).map((cliente) => ({
            id: cliente.id,
            etiqueta: cliente.denominacion
        }))
    ];

    abrirSelector('Elegir cliente', opciones, (opcion) => {
        estado.clienteId = opcion.id === 0 ? null : opcion.id;
        elemento<HTMLInputElement>('factura-cliente').value = opcion.etiqueta;
    });
}

function articulosComoOpciones(): OpcionSelector[] {
    return (estado.catalogos?.articulos ?? []).map((articulo) => ({
        id: articulo.id,
        etiqueta: `${articulo.denominacion} - ${formatearMoneda(articulo.precio ?? 0)}`
    }));
}

/** Total estimado del formulario, con bonificaciones. */
function totalEstimado(): number {
    return estado.detalles.reduce((total, detalle) => total + subtotalDe(detalle), 0);
}

function subtotalDe(detalle: FacturaDetalleRequestDTO): number {
    const precio = detalle.precioUnitario ?? 0;
    const bonificacion = detalle.porcentajeBonificacion ?? 0;
    const cantidad = detalle.cantidad ?? 0;
    return cantidad * precio * (1 - bonificacion / 100);
}

function dibujarDetalles(): void {
    const cuerpo = elemento<HTMLTableSectionElement>('detalles-cuerpo');
    cuerpo.innerHTML = '';

    estado.detalles.forEach((detalle, indice) => {
        const fila = document.createElement('tr');

        const celdaArticulo = document.createElement('td');
        const botonArticulo = document.createElement('button');
        botonArticulo.type = 'button';
        botonArticulo.className = 'boton-seleccion';
        const nombre = nombreDeArticulo(detalle.articuloId);
        botonArticulo.textContent = nombre || 'Elegir articulo';
        if (!nombre) {
            botonArticulo.classList.add('vacio');
        }
        botonArticulo.addEventListener('click', () => elegirArticulo(indice));
        celdaArticulo.appendChild(botonArticulo);

        const celdaCantidad = document.createElement('td');
        const inputCantidad = document.createElement('input');
        inputCantidad.type = 'number';
        inputCantidad.min = '1';
        inputCantidad.step = '1';
        inputCantidad.value = String(detalle.cantidad ?? 1);
        inputCantidad.addEventListener('input', () => {
            detalle.cantidad = Number(inputCantidad.value);
            actualizarFila(indice);
        });
        celdaCantidad.appendChild(inputCantidad);

        const celdaPrecio = document.createElement('td');
        const inputPrecio = document.createElement('input');
        inputPrecio.type = 'number';
        inputPrecio.min = '0';
        inputPrecio.step = '0.01';
        inputPrecio.value = String(detalle.precioUnitario ?? 0);
        inputPrecio.addEventListener('input', () => {
            detalle.precioUnitario = Number(inputPrecio.value);
            actualizarFila(indice);
        });
        celdaPrecio.appendChild(inputPrecio);

        const celdaBonificacion = document.createElement('td');
        const inputBonificacion = document.createElement('input');
        inputBonificacion.type = 'number';
        inputBonificacion.min = '0';
        inputBonificacion.max = '100';
        inputBonificacion.step = '0.01';
        inputBonificacion.value = String(detalle.porcentajeBonificacion ?? 0);
        inputBonificacion.addEventListener('input', () => {
            detalle.porcentajeBonificacion = Number(inputBonificacion.value);
            actualizarFila(indice);
        });
        celdaBonificacion.appendChild(inputBonificacion);

        const celdaSubtotal = document.createElement('td');
        celdaSubtotal.className = 'subtotal';
        celdaSubtotal.textContent = formatearMoneda(subtotalDe(detalle));

        const celdaAcciones = document.createElement('td');
        const botonQuitar = document.createElement('button');
        botonQuitar.type = 'button';
        botonQuitar.className = 'boton boton-peligro chico';
        botonQuitar.textContent = 'Quitar';
        botonQuitar.addEventListener('click', () => quitarDetalle(indice));
        celdaAcciones.appendChild(botonQuitar);

        fila.appendChild(celdaArticulo);
        fila.appendChild(celdaCantidad);
        fila.appendChild(celdaPrecio);
        fila.appendChild(celdaBonificacion);
        fila.appendChild(celdaSubtotal);
        fila.appendChild(celdaAcciones);
        cuerpo.appendChild(fila);
    });

    actualizarTotalEstimado();
}

/** Actualiza el subtotal de un renglon sin redibujar toda la tabla. */
function actualizarFila(indice: number): void {
    const detalle = estado.detalles[indice];
    const cuerpo = elemento<HTMLTableSectionElement>('detalles-cuerpo');
    const fila = cuerpo.rows[indice];
    const celda = fila?.querySelector<HTMLTableCellElement>('td.subtotal');

    if (detalle && celda) {
        celda.textContent = formatearMoneda(subtotalDe(detalle));
    }
    actualizarTotalEstimado();
}

function actualizarTotalEstimado(): void {
    elemento('total-estimado').textContent = formatearMoneda(totalEstimado());
}

/** Arma el cuerpo del POST a partir del formulario. */
function armarFactura(): FacturaRequestDTO {
    const detalles = estado.detalles
        .filter((detalle) => detalle.articuloId > 0)
        .map((detalle) => ({
            articuloId: detalle.articuloId,
            cantidad: detalle.cantidad,
            precioUnitario: detalle.precioUnitario,
            porcentajeBonificacion: detalle.porcentajeBonificacion ?? 0
        }));

    const factura: FacturaRequestDTO = {
        fechaEmision: valorDe('factura-fecha-emision'),
        condicionIvaId: numeroDe('factura-condicion-iva') ?? 0,
        puntoVentaId: numeroDe('factura-punto-venta') ?? 0,
        tipoMonedaId: numeroDe('factura-tipo-moneda') ?? 0,
        detalles
    };

    const numero = numeroDe('factura-numero');
    if (numero !== undefined) {
        factura.numero = numero;
    }

    if (estado.clienteId !== null) {
        factura.clienteId = estado.clienteId;
    }

    const observaciones = valorDe('factura-observaciones');
    if (observaciones) {
        factura.observaciones = observaciones;
    }

    return factura;
}

async function guardarFactura(): Promise<void> {
    const factura = armarFactura();

    if (!factura.fechaEmision) {
        avisar('La fecha de emision es obligatoria.', 'error');
        return;
    }
    if (factura.detalles.length === 0) {
        avisar('La factura tiene que tener al menos un renglon con articulo.', 'error');
        return;
    }
    if (!factura.condicionIvaId || !factura.puntoVentaId || !factura.tipoMonedaId) {
        avisar('Falta elegir condicion de IVA, punto de venta o moneda.', 'error');
        return;
    }

    try {
        const creada = await facturaService.crearFactura(factura);
        avisar(`Factura ${creada.numeroFactura} creada con un total de ${formatearMoneda(creada.importeTotal)}.`, 'ok');
        cerrarAlta();
        await buscarFacturas();
    } catch (error) {
        avisar(mensajeDeError(error), 'error');
    }
}

function limpiarFormulario(): void {
    estado.detalles = [crearDetalleVacio()];
    estado.clienteId = null;

    elemento<HTMLInputElement>('factura-numero').value = '';
    elemento<HTMLInputElement>('factura-fecha-emision').value = hoy();
    elemento<HTMLInputElement>('factura-cliente').value = '';
    elemento<HTMLInputElement>('factura-observaciones').value = '';
    elemento<HTMLSelectElement>('factura-condicion-iva').value = '';
    elemento<HTMLSelectElement>('factura-punto-venta').value = '';
    elemento<HTMLSelectElement>('factura-tipo-moneda').value = '';
    dibujarDetalles();
}

// ---------------------------------------------------------------------------
// Seccion 3: tabla de comprobantes
// ---------------------------------------------------------------------------

function dibujarFacturas(): void {
    const cuerpo = elemento<HTMLTableSectionElement>('facturas-cuerpo');
    cuerpo.innerHTML = '';

    if (estado.facturas.length === 0) {
        const fila = document.createElement('tr');
        const celda = document.createElement('td');
        celda.colSpan = 9;
        celda.className = 'vacio';
        celda.textContent = 'No hay facturas para mostrar.';
        fila.appendChild(celda);
        cuerpo.appendChild(fila);
        return;
    }

    estado.facturas.forEach((factura: FacturaReporteDTO) => {
        const fila = document.createElement('tr');

        const celdas: string[] = [
            String(factura.numeroFactura),
            factura.fechaEmision,
            factura.clienteDenominacion,
            factura.condicionIva,
            factura.puntoVentaDescripcion,
            String(factura.cantidadItems),
            formatearMoneda(factura.importeTotal),
            factura.estado ?? ''
        ];

        celdas.forEach((texto, indice) => {
            const celda = document.createElement('td');
            celda.textContent = texto;
            if (indice === 6) {
                celda.className = 'importe';
            }
            fila.appendChild(celda);
        });

        const celdaAcciones = document.createElement('td');
        celdaAcciones.className = 'acciones';

        const botonVer = document.createElement('button');
        botonVer.type = 'button';
        botonVer.className = 'boton chico';
        botonVer.textContent = 'Ver';
        botonVer.addEventListener('click', () => void verFactura(factura.id));
        celdaAcciones.appendChild(botonVer);

        const botonAnular = document.createElement('button');
        botonAnular.type = 'button';
        botonAnular.className = 'boton boton-alerta chico';
        botonAnular.textContent = 'Anular';
        botonAnular.disabled = factura.estado === 'ANULADA';
        botonAnular.addEventListener('click', () => void anularFactura(factura.id, factura.numeroFactura));
        celdaAcciones.appendChild(botonAnular);

        const botonEliminar = document.createElement('button');
        botonEliminar.type = 'button';
        botonEliminar.className = 'boton boton-peligro chico';
        botonEliminar.textContent = 'Eliminar';
        botonEliminar.addEventListener('click', () => void eliminarFactura(factura.id, factura.numeroFactura));
        celdaAcciones.appendChild(botonEliminar);

        fila.appendChild(celdaAcciones);
        cuerpo.appendChild(fila);
    });
}

async function verFactura(id: number): Promise<void> {
    try {
        const factura = await facturaService.obtenerFactura(id);
        avisar(`Factura ${factura.numeroFactura} del ${factura.fechaEmision}: ${factura.clienteDenominacion}, `
            + `${factura.cantidadItems} item(s), total ${formatearMoneda(factura.importeTotal)}.`, 'info');
    } catch (error) {
        avisar(mensajeDeError(error), 'error');
    }
}

async function anularFactura(id: number, numero: number): Promise<void> {
    if (!window.confirm(`Anular la factura ${numero}?`)) {
        return;
    }
    try {
        await facturaService.actualizarEstado(id, 'ANULADA', 'Anulada desde el frontend');
        avisar(`Factura ${numero} anulada.`, 'ok');
        await buscarFacturas();
    } catch (error) {
        avisar(mensajeDeError(error), 'error');
    }
}

async function eliminarFactura(id: number, numero: number): Promise<void> {
    if (!window.confirm(`Eliminar definitivamente la factura ${numero}?`)) {
        return;
    }
    try {
        await facturaService.eliminarFactura(id);
        avisar(`Factura ${numero} eliminada.`, 'ok');
        await buscarFacturas();
    } catch (error) {
        avisar(mensajeDeError(error), 'error');
    }
}

// ---------------------------------------------------------------------------
// Modal generico de seleccion (Cliente y Articulo)
// ---------------------------------------------------------------------------

function abrirSelector(titulo: string, opciones: OpcionSelector[],
                       alElegir: (opcion: OpcionSelector) => void): void {
    opcionesSelector = opciones;
    alElegirSelector = alElegir;

    elemento('selector-titulo').textContent = titulo;
    const buscador = elemento<HTMLInputElement>('selector-busqueda');
    buscador.value = '';
    dibujarOpcionesSelector();

    const modal = elemento<HTMLDialogElement>('modal-selector');
    if (!modal.open) {
        modal.showModal();
    }
    buscador.focus();
}

function cerrarSelector(): void {
    elemento<HTMLDialogElement>('modal-selector').close();
    alElegirSelector = null;
    opcionesSelector = [];
}

function dibujarOpcionesSelector(): void {
    const texto = valorDe('selector-busqueda').toLowerCase();
    const lista = elemento<HTMLUListElement>('selector-lista');
    lista.innerHTML = '';

    const filtradas = opcionesSelector.filter((opcion) =>
        opcion.etiqueta.toLowerCase().includes(texto));

    if (filtradas.length === 0) {
        const vacio = document.createElement('li');
        vacio.className = 'vacio';
        vacio.textContent = 'Sin resultados.';
        lista.appendChild(vacio);
        return;
    }

    filtradas.forEach((opcion) => {
        const item = document.createElement('li');
        const boton = document.createElement('button');
        boton.type = 'button';
        boton.className = 'opcion';
        boton.textContent = opcion.etiqueta;
        boton.addEventListener('click', () => {
            const alElegir = alElegirSelector;
            cerrarSelector();
            alElegir?.(opcion);
        });
        item.appendChild(boton);
        lista.appendChild(item);
    });
}

// ---------------------------------------------------------------------------
// Carga de catalogos
// ---------------------------------------------------------------------------

function llenarSelect(id: string, items: CatalogoItemDTO[], vacio: string): void {
    const select = elemento<HTMLSelectElement>(id);
    select.innerHTML = '';

    const opcionVacia = document.createElement('option');
    opcionVacia.value = '';
    opcionVacia.textContent = vacio;
    select.appendChild(opcionVacia);

    items.forEach((item) => {
        const opcion = document.createElement('option');
        opcion.value = String(item.id);
        opcion.textContent = item.denominacion;
        select.appendChild(opcion);
    });
}

/**
 * Llena un select de FILTRO: el value es la denominacion y no el id, porque
 * el parametro `condicionIva` de la API se compara contra
 * `CondicionIva.denominacion`.
 */
function llenarSelectDeFiltro(id: string, items: CatalogoItemDTO[], vacio: string): void {
    const select = elemento<HTMLSelectElement>(id);
    select.innerHTML = '';

    const opcionVacia = document.createElement('option');
    opcionVacia.value = '';
    opcionVacia.textContent = vacio;
    select.appendChild(opcionVacia);

    items.forEach((item) => {
        const opcion = document.createElement('option');
        opcion.value = item.denominacion;
        opcion.textContent = item.denominacion;
        select.appendChild(opcion);
    });
}

/** Sugerencias del filtro de cliente: salen del catalogo, no de una lista fija. */
function llenarSugerenciasDeCliente(items: CatalogoItemDTO[]): void {
    const datalist = elemento<HTMLDataListElement>('clientes-sugeridos');
    datalist.innerHTML = '';

    items.forEach((cliente) => {
        const opcion = document.createElement('option');
        opcion.value = cliente.denominacion;
        datalist.appendChild(opcion);
    });
}

async function cargarCatalogos(): Promise<void> {
    try {
        estado.catalogos = await facturaService.obtenerCatalogos();

        llenarSelectDeFiltro('filtro-condicion-iva', estado.catalogos.condicionesIva, 'Todas');
        llenarSugerenciasDeCliente(estado.catalogos.clientes);

        llenarSelect('factura-condicion-iva', estado.catalogos.condicionesIva, 'Elegir condicion');
        llenarSelect('factura-punto-venta', estado.catalogos.puntosVenta, 'Elegir punto de venta');
        llenarSelect('factura-tipo-moneda', estado.catalogos.monedas, 'Elegir moneda');

        dibujarDetalles();
    } catch (error) {
        avisar(`No se pudieron cargar los catalogos: ${mensajeDeError(error)}`, 'error');
    }
}

// ---------------------------------------------------------------------------
// Arranque
// ---------------------------------------------------------------------------

function conectarEventos(): void {
    elemento<HTMLFormElement>('form-busqueda').addEventListener('submit', (evento) => {
        evento.preventDefault();
        void buscarFacturas();
    });
    elemento('btn-limpiar-filtros').addEventListener('click', () => limpiarFiltros());

    elemento('btn-nuevo').addEventListener('click', () => abrirAlta());
    elemento('btn-cerrar-alta').addEventListener('click', () => cerrarAlta());
    elemento('btn-cancelar-factura').addEventListener('click', () => cerrarAlta());
    elemento('btn-guardar-factura').addEventListener('click', () => void guardarFactura());
    elemento('btn-agregar-detalle').addEventListener('click', () => agregarDetalle());
    elemento('btn-elegir-cliente').addEventListener('click', () => elegirCliente());

    elemento('selector-busqueda').addEventListener('input', () => dibujarOpcionesSelector());
    elemento('btn-cerrar-selector').addEventListener('click', () => cerrarSelector());
    elemento('btn-cancelar-selector').addEventListener('click', () => cerrarSelector());
}

async function iniciar(): Promise<void> {
    conectarEventos();

    elemento<HTMLInputElement>('factura-fecha-emision').value = hoy();
    estado.detalles = [crearDetalleVacio()];
    dibujarDetalles();

    await cargarCatalogos();
    await buscarFacturas();
}

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => void iniciar());
} else {
    void iniciar();
}

/** Devuelve un mensaje legible para cualquier error (de API o de red). */
function mensajeDeError(error: unknown): string {
    if (error instanceof ApiError) {
        const detalles = error.detalles.length > 0 ? ` (${error.detalles.join('; ')})` : '';
        return `${error.mensaje}${detalles}`;
    }
    if (error instanceof Error) {
        return error.message;
    }
    return 'Ocurrio un error inesperado';
}
