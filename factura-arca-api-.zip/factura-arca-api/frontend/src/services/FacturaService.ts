/**
 * Capa de cliente HTTP del frontend.
 *
 * Centraliza todas las llamadas al backend: el resto de la aplicacion nunca
 * usa `fetch` directamente. Cada metodo devuelve una promesa con el tipo que
 * devuelve la API, o lanza un `ApiError` con el codigo y el mensaje que
 * envio el `@ControllerAdvice`.
 */

import {
    CatalogosDTO,
    ErrorResponseDTO,
    FacturaEstadoRequestDTO,
    FacturaFiltrosDTO,
    FacturaReporteDTO,
    FacturaRequestDTO
} from '../models/factura.dto.js';

const API_BASE_URL = 'http://localhost:8080/api/facturas';
const CATALOGOS_URL = 'http://localhost:8080/api/catalogos';

/** Error de la API: trae el codigo HTTP y los detalles que devuelve el backend. */
export class ApiError extends Error {
    readonly status: number;
    readonly mensaje: string;
    readonly detalles: string[];

    constructor(status: number, mensaje: string, detalles: string[] = []) {
        super(mensaje);
        this.name = 'ApiError';
        this.status = status;
        this.mensaje = mensaje;
        this.detalles = detalles;
    }
}

/**
 * Traduce la respuesta HTTP en el dato que espera el llamador.
 *
 * Un 204 no tiene cuerpo: se devuelve `undefined` y no se intenta parsear
 * JSON, porque `respuesta.json()` sobre un cuerpo vacio revienta.
 */
async function manejarRespuesta<T>(respuesta: Response): Promise<T> {
    if (respuesta.ok) {
        if (respuesta.status === 204 || respuesta.headers.get('content-length') === '0') {
            return undefined as T;
        }
        const texto = await respuesta.text();
        return (texto ? JSON.parse(texto) : undefined) as T;
    }

    throw await construirError(respuesta);
}

/** Arma el `ApiError` a partir del cuerpo de error del backend. */
async function construirError(respuesta: Response): Promise<ApiError> {
    let cuerpo: ErrorResponseDTO | null = null;
    try {
        cuerpo = (await respuesta.json()) as ErrorResponseDTO;
    } catch {
        // Si el backend no devuelve JSON (por ejemplo un 502 del proxy), se
        // devuelve un error generico con el status y el statusText.
    }

    const mensaje = cuerpo?.mensaje ?? `Error ${respuesta.status}: ${respuesta.statusText}`;
    const detalles = cuerpo?.detalles ?? [];
    return new ApiError(respuesta.status, mensaje, detalles);
}

/** Arma el query string de los filtros, dejando afuera los vacios. */
function construirQueryString(filtros: FacturaFiltrosDTO): string {
    const params = new URLSearchParams();

    if (filtros.numeroFactura !== undefined && filtros.numeroFactura !== null) {
        params.append('numeroFactura', String(filtros.numeroFactura));
    }
    if (filtros.clienteDenominacion) {
        params.append('clienteDenominacion', filtros.clienteDenominacion);
    }
    if (filtros.condicionIva) {
        params.append('condicionIva', filtros.condicionIva);
    }
    if (filtros.fechaDesde) {
        params.append('fechaDesde', filtros.fechaDesde);
    }
    if (filtros.fechaHasta) {
        params.append('fechaHasta', filtros.fechaHasta);
    }

    const query = params.toString();
    return query ? `?${query}` : '';
}

/**
 * Cliente de la API de facturas.
 *
 * <p>Es una clase (y no un simple objeto de funciones) para poder tener
 * varias instancias con distintas URLs base, por ejemplo en los tests.
 */
export class FacturaService {

    private readonly baseUrl: string;
    private readonly catalogosUrl: string;

    constructor(baseUrl: string = API_BASE_URL, catalogosUrl: string = CATALOGOS_URL) {
        this.baseUrl = baseUrl;
        this.catalogosUrl = catalogosUrl;
    }

    /** GET /api/facturas - listado con filtros opcionales. */
    async obtenerFacturas(filtros: FacturaFiltrosDTO = {}): Promise<FacturaReporteDTO[]> {
        const respuesta = await fetch(`${this.baseUrl}${construirQueryString(filtros)}`);
        return manejarRespuesta<FacturaReporteDTO[]>(respuesta);
    }

    /** GET /api/facturas/{id} - una sola factura. */
    async obtenerFactura(id: number): Promise<FacturaReporteDTO> {
        const respuesta = await fetch(`${this.baseUrl}/${id}`);
        return manejarRespuesta<FacturaReporteDTO>(respuesta);
    }

    /** POST /api/facturas - crea la factura y devuelve la que creo el backend. */
    async crearFactura(factura: FacturaRequestDTO): Promise<FacturaReporteDTO> {
        const respuesta = await fetch(this.baseUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(factura)
        });
        return manejarRespuesta<FacturaReporteDTO>(respuesta);
    }

    /** PUT /api/facturas/{id} - actualiza la cabecera y los detalles. */
    async actualizarFactura(id: number, factura: FacturaRequestDTO): Promise<FacturaReporteDTO> {
        const respuesta = await fetch(`${this.baseUrl}/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(factura)
        });
        return manejarRespuesta<FacturaReporteDTO>(respuesta);
    }

    /**
     * PUT /api/facturas/{id}/estado
     *
     * <p>Es la operacion de anulacion: manda el estado nuevo (por ejemplo
     * `ANULADA`) y, si se quiere, una observacion.
     */
    async actualizarEstado(id: number, estado: string, observaciones?: string): Promise<FacturaReporteDTO> {
        const cuerpo: FacturaEstadoRequestDTO = { estado, observaciones };

        const respuesta = await fetch(`${this.baseUrl}/${id}/estado`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(cuerpo)
        });
        return manejarRespuesta<FacturaReporteDTO>(respuesta);
    }

    /** DELETE /api/facturas/{id} - borra la factura. Responde 204, sin cuerpo. */
    async eliminarFactura(id: number): Promise<void> {
        const respuesta = await fetch(`${this.baseUrl}/${id}`, { method: 'DELETE' });
        await manejarRespuesta<void>(respuesta);
    }

    /** GET /api/catalogos - los catalogos que necesita el formulario de alta. */
    async obtenerCatalogos(): Promise<CatalogosDTO> {
        const respuesta = await fetch(this.catalogosUrl);
        return manejarRespuesta<CatalogosDTO>(respuesta);
    }
}

/** Instancia unica que usa la aplicacion. */
export const facturaService = new FacturaService();
