/**
 * Espejo en TypeScript de los DTOs de Java.
 *
 * Cada interface de este archivo corresponde, campo por campo, con una clase
 * del paquete `org.example.facturaarca.dto`. Si se cambia un DTO del backend,
 * hay que cambiar la interface de acá: es el "contrato" que comparten las dos
 * capas.
 *
 * - FacturaReporteDTO        <-> dto/FacturaReporteDTO.java
 * - FacturaRequestDTO        <-> dto/FacturaRequestDTO.java
 * - FacturaDetalleRequestDTO <-> dto/FacturaDetalleRequestDTO.java
 * - FacturaEstadoRequestDTO  <-> dto/FacturaEstadoRequestDTO.java
 * - CatalogoItemDTO          <-> dto/CatalogoItemDTO.java
 */

/** Estados validos de una factura. Espejo del enum `EstadoFactura` de Java. */
export type EstadoFactura = 'EMITIDA' | 'AUTORIZADA' | 'ANULADA' | 'RECHAZADA';

export const ESTADOS_FACTURA: readonly EstadoFactura[] = [
    'EMITIDA',
    'AUTORIZADA',
    'ANULADA',
    'RECHAZADA'
];

/** Proyeccion plana del reporte de ventas: es lo que devuelve el listado. */
export interface FacturaReporteDTO {
    id: number;
    numeroFactura: number;
    /** Fecha de emision en formato yyyy-MM-dd. */
    fechaEmision: string;
    clienteDenominacion: string;
    condicionIva: string;
    puntoVentaDescripcion: string;
    /** EMITIDA, AUTORIZADA, ANULADA o RECHAZADA. */
    estado: EstadoFactura | string;
    importeTotal: number;
    cantidadItems: number;
}

/** Renglon del alta o la edicion de una factura. */
export interface FacturaDetalleRequestDTO {
    /** Id del articulo (no del precio de lista). */
    articuloId: number;
    cantidad: number;
    /** Si no se manda, el backend toma el precio de la lista. */
    precioUnitario?: number;
    porcentajeBonificacion?: number;
}

/** Cabecera del alta o la edicion de una factura. */
export interface FacturaRequestDTO {
    numero?: number;
    /** Fecha de emision en formato yyyy-MM-dd. */
    fechaEmision: string;
    /** Si no se manda, la factura es para Consumidor Final. */
    clienteId?: number;
    condicionIvaId: number;
    puntoVentaId: number;
    tipoMonedaId: number;
    estado?: EstadoFactura | string;
    observaciones?: string;
    detalles: FacturaDetalleRequestDTO[];
}

/** Cambio de estado (por ejemplo, la anulacion). */
export interface FacturaEstadoRequestDTO {
    estado: EstadoFactura | string;
    observaciones?: string;
}

/** Filtros del reporte: todos opcionales y se combinan entre si. */
export interface FacturaFiltrosDTO {
    /** FacturaVenta.numero */
    numeroFactura?: number;
    /** Cliente.denominacion (coincidencia parcial) */
    clienteDenominacion?: string;
    /** CondicionIva.denominacion */
    condicionIva?: string;
    /** FacturaVenta.fechaEmision, formato yyyy-MM-dd */
    fechaDesde?: string;
    /** FacturaVenta.fechaEmision, formato yyyy-MM-dd */
    fechaHasta?: string;
}

/** Item de catalogo: el mismo tipo para todos los desplegables del formulario. */
export interface CatalogoItemDTO {
    id: number;
    denominacion: string;
    precio?: number;
}

/** Los cinco catalogos que carga el formulario de una sola vez. */
export interface CatalogosDTO {
    articulos: CatalogoItemDTO[];
    clientes: CatalogoItemDTO[];
    condicionesIva: CatalogoItemDTO[];
    puntosVenta: CatalogoItemDTO[];
    monedas: CatalogoItemDTO[];
}

/** Cuerpo de error que devuelve el `@ControllerAdvice` del backend. */
export interface ErrorResponseDTO {
    status: number;
    mensaje: string;
    fecha: string;
    detalles: string[];
}

/** Devuelve el dia de hoy en yyyy-MM-dd, que es el formato que espera la API. */
export function hoy(): string {
    const ahora = new Date();
    const mes = String(ahora.getMonth() + 1).padStart(2, '0');
    const dia = String(ahora.getDate()).padStart(2, '0');
    return `${ahora.getFullYear()}-${mes}-${dia}`;
}

/**
 * Renglon vacio para la tabla dinamica del formulario.
 * El precio se carga desde el catalogo cuando se elige el articulo.
 */
export function crearDetalleVacio(): FacturaDetalleRequestDTO {
    return {
        articuloId: 0,
        cantidad: 1,
        precioUnitario: 0,
        porcentajeBonificacion: 0
    };
}
