/**
 * Servidor estatico minimo para desarrollo, sin dependencias.
 *
 * Sirve `public/` en http://localhost:3000 y el TypeScript compilado desde
 * /assets/js, para probar el frontend contra la API en otro puerto.
 *
 *   npm run serve
 */

import { createReadStream, existsSync, statSync } from 'node:fs';
import { createServer } from 'node:http';
import { dirname, extname, join, normalize, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const raizFrontend = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const carpetaPublica = resolve(raizFrontend, 'public');
const carpetaJs = resolve(raizFrontend, '..', 'src', 'main', 'resources', 'static', 'assets', 'js');
const PUERTO = Number(process.env.PORT ?? 3000);

const tipos = {
    '.html': 'text/html; charset=utf-8',
    '.css': 'text/css; charset=utf-8',
    '.js': 'text/javascript; charset=utf-8',
    '.map': 'application/json; charset=utf-8',
    '.json': 'application/json; charset=utf-8'
};

function resolver(ruta) {
    const limpia = normalize(decodeURIComponent(ruta.split('?')[0])).replace(/^(\.\.[/\\])+/, '');
    if (limpia.startsWith('/assets/js')) {
        return join(carpetaJs, limpia.replace('/assets/js', ''));
    }
    return join(carpetaPublica, limpia === '/' ? 'index.html' : limpia);
}

createServer((peticion, respuesta) => {
    const archivo = resolver(peticion.url ?? '/');

    if (!existsSync(archivo) || !statSync(archivo).isFile()) {
        respuesta.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
        respuesta.end('No encontrado: ' + archivo);
        return;
    }

    respuesta.writeHead(200, {
        'Content-Type': tipos[extname(archivo)] ?? 'application/octet-stream',
        'Cache-Control': 'no-store'
    });
    createReadStream(archivo).pipe(respuesta);
}).listen(PUERTO, () => {
    console.log(`Frontend en http://localhost:${PUERTO}`);
    console.log(`API esperada en http://localhost:8080`);
});
