/**
 * Copia los archivos estaticos del frontend (index.html, estilos.css) a la
 * carpeta de recursos de Spring Boot, para que la misma aplicacion sirva la
 * API y la pagina.
 *
 *   frontend/public  ->  src/main/resources/static
 */

import { cp, mkdir } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const raizFrontend = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const origen = resolve(raizFrontend, 'public');
const destino = resolve(raizFrontend, '..', 'src', 'main', 'resources', 'static');

await mkdir(destino, { recursive: true });
await cp(origen, destino, { recursive: true });

console.log(`Estaticos copiados:\n  ${origen}\n  -> ${destino}`);
