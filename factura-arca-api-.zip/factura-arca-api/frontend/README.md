# Frontend CRUD de facturas

TP de Programacion III - parte de TypeScript + HTML5 del CRUD de facturas de venta.

## Estructura

```
public/index.html            las tres secciones: busqueda, alta y listado
public/estilos.css           estilos de la pagina
src/models/factura.dto.ts    interfaces que espejan los DTOs de Java
src/services/FacturaService.ts  capa de cliente HTTP (fetch + async/await)
src/app.ts                   DOM, estado en memoria y eventos
scripts/copiar-estaticos.mjs copia el HTML/CSS a src/main/resources/static
scripts/servidor-estatico.mjs  servidor de desarrollo sin dependencias
```

## Como usarlo

```bash
npm install
npm run build      # compila a ../src/main/resources/static/assets/js y copia el HTML
npm run typecheck  # solo chequea tipos, sin generar nada
npm run serve      # servidor estatico en http://localhost:3000
```

`npm run build` deja el frontend servido por la misma aplicacion de Spring Boot:
con la API corriendo, la pagina esta en <http://localhost:8080/index.html>.

## La API

La capa `FacturaService` habla con `http://localhost:8080/api/facturas`:

```ts
obtenerFacturas(filtros)            // GET    /api/facturas
obtenerFactura(id)                  // GET    /api/facturas/{id}
crearFactura(factura)               // POST   /api/facturas        -> 201
actualizarFactura(id, factura)      // PUT    /api/facturas/{id}   -> 200
actualizarEstado(id, estado, obs)   // PUT    /api/facturas/{id}/estado -> 200
eliminarFactura(id)                 // DELETE /api/facturas/{id}   -> 204
obtenerCatalogos()                  // GET    /api/catalogos
```

Los errores del backend llegan como `ApiError` (status + mensaje + detalles), porque el
`@ControllerAdvice` siempre responde el mismo JSON.
