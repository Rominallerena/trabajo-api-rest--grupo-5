# factura-arca-api

TP de **Programacion III**: API REST con Spring Boot.

- **TP 1** - Lombok, DTOs y servicios web REST (reporte de ventas con JPQL, PDF y Excel).
- **TP 2 (este)** - Operaciones de escritura en la API REST (`POST`, `PUT`, `DELETE`) y
  frontend CRUD con TypeScript + HTML5.

El proyecto quedo al lado de `FacturaArca` (el TP de JPQL), que sigue intacto. El modelo de
entidades se porte a este proyecto refactorizado con Lombok y migrado a `jakarta.persistence`,
porque Spring Boot 3.x ya no usa `javax.persistence`.

## Stack

| Pieza | Version | Por que |
|---|---|---|
| Java | 21 | Spring Boot 3.x pide 17+ |
| Spring Boot | 3.5.16 | ultima 3.x, la linea de los apuntes |
| JPA | Jakarta Persistence 3.1 (Hibernate 6.6) | la trae `spring-boot-starter-data-jpa` |
| Build | Maven (`mvnw`) | lo que genera Spring Initializr por defecto |
| Base | MySQL (perfil `dev` / `prod`) o H2 (perfil `local`) | |
| Lombok | 1.18.x (gestionado por el parent) | TP 1 |
| iText | 5.5.13.4 | PDF, TP 1 |
| Apache POI | 5.5.1 | Excel `.xlsx`, TP 1 |
| Springdoc OpenAPI | 2.8.9 | Swagger UI (`/swagger-ui.html`) |
| TypeScript | 5.6 | Frontend del CRUD |

## Como correrlo

### Opcion A: sin configurar nada (perfil `local`, base H2 en archivo)

```bash
./mvnw spring-boot:run -Dspring-boot.run.profiles=local
```

Crea el esquema en `./data/facturaarca.mv.db`, siembra 12 facturas de prueba y levanta la API
en `http://localhost:8080`. Consola de H2 en `http://localhost:8080/h2-console`.

Con el perfil `local` tambien se sirve el frontend: `http://localhost:8080/index.html`.

### Opcion B: contra la base MySQL remota (perfil `dev`, el que esta por defecto)

```bash
./mvnw spring-boot:run
```

La conexion ya esta en `application-dev.properties`
(`db72283.public.databaseasp.net:3306/db72283`, usuario `db72283`).

### Frontend (TypeScript)

```bash
cd frontend
npm install
npm run build      # compila el TS a src/main/resources/static/assets/js y copia el HTML
```

Despues, con la aplicacion corriendo, la pagina esta en `http://localhost:8080/index.html`.

Para trabajar el frontend en otro puerto (por ejemplo para ver los pedidos en las herramientas
del navegador):

```bash
cd frontend
npm run serve      # servidor estatico propio en http://localhost:3000
```

El backend tiene CORS abierto para `/api/**` (`app.cors.origins`), asi que el frontend puede
consumir la API desde otro origen.

### Tests

```bash
./mvnw test
```

28 tests contra H2 en memoria. No tocan ninguna base remota.

## Endpoints

| Metodo | Ruta | Que hace | Codigo |
|---|---|---|---|
| GET | `/api/facturas` | Reporte en JSON como lista de `FacturaReporteDTO` | 200 |
| GET | `/api/facturas/{id}` | Una factura por id | 200 / 404 |
| GET | `/api/facturas/reporte?formato=pdf\|xlsx` | Descarga el reporte como archivo | 200 |
| POST | `/api/facturas/reporte/archivos` | Escribe el PDF y el Excel en `./reportes` y devuelve las rutas | 200 |
| **POST** | **`/api/facturas`** | **Crea una factura con sus detalles en cascada** | **201** |
| **PUT** | **`/api/facturas/{id}`** | **Actualiza cabecera y detalle** | **200** |
| **PUT** | **`/api/facturas/{id}/estado`** | **Anula o cambia el estado** | **200** |
| **DELETE** | **`/api/facturas/{id}`** | **Elimina la factura** | **204** |
| GET | `/api/catalogos` | Articulos, clientes, condiciones de IVA, puntos de venta y monedas | 200 |
| GET | `/api/catalogos/{articulos\|clientes\|condiciones-iva\|puntos-venta\|monedas}` | Un catalogo puntual | 200 |

Los filtros del listado salen del modelo de datos y son todos opcionales; se combinan entre si:

| Parametro | Campo del modelo | Comparacion |
|---|---|---|
| `numeroFactura` | `FacturaVenta.numero` | igualdad exacta |
| `clienteDenominacion` | `Cliente.denominacion` (o `"Consumidor Final"` si no hay cliente) | `LIKE` parcial, sin distinguir mayusculas |
| `condicionIva` | `CondicionIva.denominacion` | `LIKE` parcial, sin distinguir mayusculas |
| `fechaDesde` | `FacturaVenta.fechaEmision` (`yyyy-MM-dd`) | `>=` inicio del dia |
| `fechaHasta` | `FacturaVenta.fechaEmision` (`yyyy-MM-dd`) | `<=` fin del dia |
| `estado` | `FacturaVenta.estado` | igualdad (`EMITIDA`, `AUTORIZADA`, `ANULADA`, `RECHAZADA`) |
| `montoMinimo` | `FacturaVenta.importeTotal` | `>=` |

Los cinco primeros son los que ofrece la pantalla de busqueda; `estado` y `montoMinimo` quedaron
disponibles en la API (y en el reporte) porque los usa la Parte 1, aunque la tabla del CRUD ya
muestra el estado en una columna.

```bash
curl "http://localhost:8080/api/facturas"
curl "http://localhost:8080/api/facturas?numeroFactura=1004"
curl "http://localhost:8080/api/facturas?clienteDenominacion=sur"
curl "http://localhost:8080/api/facturas?condicionIva=Monotributo"
curl "http://localhost:8080/api/facturas?fechaDesde=2026-01-01&fechaHasta=2026-02-22"
curl "http://localhost:8080/api/facturas?clienteDenominacion=sur&condicionIva=Monotributo"
curl -o reporte.pdf  "http://localhost:8080/api/facturas/reporte?formato=pdf"
curl -o reporte.xlsx "http://localhost:8080/api/facturas/reporte?formato=xlsx&montoMinimo=400000"

# Alta de una factura (201 Created + cabecera Location)
curl -i -X POST http://localhost:8080/api/facturas \
  -H "Content-Type: application/json" \
  -d '{"fechaEmision":"2026-10-20","clienteId":2,"condicionIvaId":1,"puntoVentaId":1,"tipoMonedaId":1,
       "detalles":[{"articuloId":3,"cantidad":2}]}'

# Anulacion (200 OK)
curl -X PUT http://localhost:8080/api/facturas/13/estado \
  -H "Content-Type: application/json" -d '{"estado":"ANULADA","observaciones":"Error de carga"}'

# Borrado (204 No Content)
curl -i -X DELETE http://localhost:8080/api/facturas/13
```

Respuesta de ejemplo:

```json
[
  {
    "id": 1,
    "numeroFactura": 1001,
    "fechaEmision": "2026-01-15",
    "clienteDenominacion": "Consumidor Final",
    "condicionIva": "IVA Responsable Inscripto",
    "puntoVentaDescripcion": "Sucursal Centro",
    "estado": "EMITIDA",
    "importeTotal": 41500.0,
    "cantidadItems": 2
  }
]
```

## Documentacion de la API

Con la aplicacion corriendo:

- Swagger UI: <http://localhost:8080/swagger-ui.html>
- Especificacion OpenAPI en JSON: <http://localhost:8080/v3/api-docs>

La cabecera (titulo, version, contacto) sale del bean `OpenAPI` de
`config/ConfiguracionOpenApi.java`.

## Donde esta cada consigna

### Parte 1 — Lombok en el modelo de dominio

`src/main/java/org/example/facturaarca/entidades/`

- Dependencia de Lombok en `pom.xml`, con `<optional>true</optional>` y excluida del JAR final.
- `EntityId` y `AuditoriaApp` son las superclases `@MappedSuperclass` con `@Getter`, `@Setter`,
  `@NoArgsConstructor`, `@AllArgsConstructor`.
- Las entidades concretas llevan `@EqualsAndHashCode(callSuper = true)`, como pide la consigna.
- `@Getter`/`@Setter` en lugar de `@Data`, y en `FacturaVenta` / `FacturaVentaDetalle` la
  relacion bidireccional queda excluida de `toString()` y `equals()`:

  ```java
  @EqualsAndHashCode(callSuper = true, exclude = {"detalles"})
  @ToString(callSuper = true, exclude = {"detalles", ...})
  public class FacturaVenta extends AuditoriaApp { ... }
  ```

  Sin eso, `factura.toString()` recorre sus detalles, cada detalle vuelve a la factura y se
  cae con `StackOverflowError`.

**Dos decisiones que se apartan del ejemplo del enunciado, a proposito:**

1. Se usa `@SuperBuilder` y no `@Builder`. Con `@Builder` a secas, el builder de `FacturaVenta`
   solo puede cargar los campos propios: los heredados de `AuditoriaApp` (`fechaAlta`,
   `usuarioCarga`, etc.) quedan afuera. `@SuperBuilder`, puesto en toda la jerarquia, los incluye.
2. Las asociaciones LAZY tambien se excluyen de `toString()`. No es por recursion sino porque
   imprimir una entidad desacoplada dispararia una `LazyInitializationException`.

### Parte 2 — Proyeccion DTO con JPQL + PDF y Excel

- `dto/FacturaReporteDTO.java`: los 8 campos pedidos, con `@Getter`, `@Setter`,
  `@AllArgsConstructor` y `@NoArgsConstructor`.
- `repository/FacturaReporteRepository.java`: la consulta con expresion de constructor.
  Hibernate instancia el DTO directamente desde el `ResultSet`, sin materializar entidades:

  ```sql
  SELECT new org.example.facturaarca.dto.FacturaReporteDTO(
    f.id, f.numero, f.fechaEmision, COALESCE(c.denominacion, 'Consumidor Final'),
    ci.denominacion, pv.descripcion, f.estado, f.importeTotal, COUNT(d))
  FROM FacturaVenta f
  LEFT JOIN f.cliente c
  JOIN f.condicionIva ci
  JOIN f.puntoVenta pv
  JOIN f.detalles d
  GROUP BY f.id, f.numero, f.fechaEmision, c.denominacion,
           ci.denominacion, pv.descripcion, f.estado, f.importeTotal
  ORDER BY f.numero
  ```

  El `LEFT JOIN` sobre `cliente` es lo que permite que el `COALESCE` devuelva
  `"Consumidor Final"` cuando la factura no tiene cliente.
- `service/reporte/GeneradorReportePdf.java`: PDF con iText, tabla A4 horizontal con fila de totales.
- `service/reporte/GeneradorReporteExcel.java`: `.xlsx` real con Apache POI. El enunciado
  permitia un txt separado por tabulaciones; se hizo un Excel de verdad para que los importes
  queden como numeros y la fila de totales use formulas `SUM()`.
- Los dos implementan `GeneradorReporte`. `ReporteFacturaService` recibe por constructor la
  **lista** de generadores que encontro Spring y los indexa por formato, asi que sumar un
  formato nuevo es agregar un `@Component` sin tocar nada de lo existente.

### Parte 3 — API REST con filtros opcionales

- `FacturaArcaApiApplication`: `@SpringBootApplication` + `@ConfigurationPropertiesScan`.
- `repository/FacturaReporteRepository` (`@Repository`): arma el JPQL en tiempo de ejecucion con
  `StringBuilder` + `WHERE 1=1` y parametros nombrados, agregando un `AND` por cada filtro no nulo.
- `service/FacturaService` (`@Service`): sin filtros usa la consulta fija; con filtros, la dinamica.
- `web/FacturaRestController` (`@RestController`): mapeado en `/api/facturas`, con los cuatro
  `@RequestParam(required = false)`.
- `web/ManejadorErroresApi` (`@RestControllerAdvice`): devuelve 400 con cuerpo JSON ante un
  formato invalido o una fecha mal escrita, en vez del 500 generico.

Todas las dependencias entran **por constructor**, no por `@Autowired` en el campo: los campos
quedan `final`, el bean nunca existe a medio construir y las clases se pueden testear con mocks
sin levantar el contexto.

### Parte 4 — DTOs de entrada (Request DTOs)

- `dto/FacturaRequestDTO.java`: cabecera del alta y de la edicion. Las relaciones viajan
  **como ids** (`clienteId`, `condicionIvaId`, `puntoVentaId`, `tipoMonedaId`), nunca como
  entidades anidadas, para no acoplar el JSON al modelo JPA.
- `dto/FacturaDetalleRequestDTO.java`: renglon del alta. Solo viaja `articuloId` y `cantidad`;
  el precio lo resuelve el servicio contra `ListaPrecioArticulo`.
- `dto/FacturaEstadoRequestDTO.java`: el cambio de estado (`estado` + `observaciones`).
- `dto/CatalogoItemDTO.java`: item de catalogo (`id`, `denominacion`, `precio`).

Las validaciones van con Bean Validation (`@NotNull`, `@NotEmpty`, `@Positive`, `@NotBlank`), y
la cascada se valida con `@Valid` sobre la lista de detalles.

### Parte 5 — Logica de negocio en la capa de servicio

`service/FacturaService.java`, con `@Transactional` en cada metodo de escritura:

- `crear(FacturaRequestDTO)`: busca las entidades asociadas por id (PuntoVenta, CondicionIva,
  TipoMoneda, Cliente, ListaPrecioArticulo) y **lanza `RecursoNoEncontradoException` si alguna
  no existe**; mapea el DTO a la entidad, calcula netos, IVA y total, y guarda la factura con
  un solo `save` (los detalles entran por `CascadeType.ALL`). Si no mandan el numero, se usa el
  siguiente correlativo; si mandan uno que ya existe, se rechaza con 400.
- `actualizar(id, request)`: busca la factura (404 si no existe), reemplaza la cabecera y los
  items y recalcula los totales. Una factura anulada no se puede modificar (400).
- `actualizarEstado(id, request)`: cambia el estado; si es `ANULADA` carga `fechaAnulacion`.
- `eliminar(id)`: eliminacion fisica; la cabecera y los detalles salen juntos por la cascada.

El estado se valida contra el enum `entidades/EstadoFactura.java`: un estado desconocido se
rechaza con 400 en vez de guardarse como texto libre.

### Parte 6 — Capa de controladores REST

`web/FacturaRestController.java`, con los codigos que pide el enunciado:

| Endpoint | Codigo | Body de la respuesta |
|---|---|---|
| `POST /api/facturas` | `201 Created` (+ cabecera `Location`) | `FacturaReporteDTO` |
| `PUT /api/facturas/{id}` | `200 OK` | `FacturaReporteDTO` |
| `PUT /api/facturas/{id}/estado` | `200 OK` | `FacturaReporteDTO` |
| `DELETE /api/facturas/{id}` | `204 No Content` | vacio |
| `GET /api/facturas/{id}` | `200 OK` / `404 Not Found` | `FacturaReporteDTO` |

`web/CatalogoRestController.java` expone los catalogos que necesita el formulario.

### Parte 7 — Manejo de errores

`web/ManejadorErroresApi.java` (`@RestControllerAdvice`) centraliza todas las respuestas de
error con el mismo cuerpo:

```json
{
  "status": 404,
  "mensaje": "Recurso no encontrado",
  "fecha": "2026-10-21T16:25:44.4718664",
  "detalles": ["No existe la factura con id 13"]
}
```

| Excepcion | Codigo |
|---|---|
| `RecursoNoEncontradoException` | 404 |
| `MethodArgumentNotValidException` (Bean Validation) | 400, con un detalle por campo |
| `HttpMessageNotReadableException` (JSON roto) | 400 |
| `IllegalArgumentException` | 400 |
| `FormatoReporteNoSoportadoException` | 400 |
| `MethodArgumentTypeMismatchException` | 400 |
| cualquier otra | 500 |

Las excepciones que ya traen su status (404 de ruta, 405, 415...) se dejan pasar: si las
absorbiera el advice, todas irian como 500.

### Parte 8 — Frontend CRUD con TypeScript y HTML5

`frontend/`

```
frontend/
  package.json
  tsconfig.json
  public/
    index.html          -> las tres secciones del enunciado
    estilos.css
  src/
    models/factura.dto.ts     -> interfaces que espejan los DTOs de Java
    services/FacturaService.ts-> capa de cliente HTTP (fetch + async/await)
    app.ts                    -> DOM, estado en memoria y eventos
  scripts/
    copiar-estaticos.mjs      -> copia el HTML/CSS a src/main/resources/static
    servidor-estatico.mjs     -> servidor de desarrollo sin dependencias
```

**Seccion 5 - Interfaces TypeScript** (`models/factura.dto.ts`): `FacturaReporteDTO`,
`FacturaRequestDTO`, `FacturaDetalleRequestDTO`, `FacturaEstadoRequestDTO`, `FacturaFiltrosDTO`
y `CatalogoItemDTO`, con los mismos nombres de campo y tipos que los DTOs de Java. Si se toca
un DTO del backend, hay que tocar la interface de aca.

**Seccion 6 - Capa de servicio API** (`services/FacturaService.ts`): la clase `FacturaService`
centraliza las llamadas a `http://localhost:8080/api/facturas`:

```ts
obtenerFacturas(filtros: FacturaFiltrosDTO): Promise<FacturaReporteDTO[]>
obtenerFactura(id: number): Promise<FacturaReporteDTO>
crearFactura(factura: FacturaRequestDTO): Promise<FacturaReporteDTO>
actualizarFactura(id: number, factura: FacturaRequestDTO): Promise<FacturaReporteDTO>
actualizarEstado(id: number, estado: string, observaciones?: string): Promise<FacturaReporteDTO>
eliminarFactura(id: number): Promise<void>
obtenerCatalogos(): Promise<CatalogosDTO>
```

Todas usan `async`/`await` sobre `fetch`. Un error del backend (404, 400...) llega como un
`ApiError` con el status, el mensaje y los detalles, porque el `@ControllerAdvice` siempre
responde el mismo JSON.

**Seccion 7 - Interfaz de usuario** (`public/index.html` + `src/app.ts`): tres secciones.

1. *Busqueda*: los cinco filtros del modelo (`numeroFactura`, `clienteDenominacion`,
   `condicionIva`, `fechaDesde`, `fechaHasta`). El select de condicion de IVA y las sugerencias
   del cliente se llenan desde `/api/catalogos`, no hay listas fijas en el HTML.
2. *Alta*: se abre con **+ Nuevo comprobante** en un `<dialog>` nativo. Tiene el formulario de
   cabecera + **tabla dinamica** de renglones: los renglones viven en memoria (`estado.detalles`),
   se agregan y se quitan con botones, y el total estimado se recalcula en cada cambio.
   **Cliente** y **Articulo** no son `<select>`: se eligen en un modal con buscador
   (`#modal-selector`), porque con muchos registros un desplegable es inusable. El precio se
   toma del catalogo al elegir el articulo, igual que hace el backend si no se manda.
3. *Comprobantes*: tabla con el listado y las acciones por fila: **Ver**, **Anular** (PUT del
   estado) y **Eliminar** (DELETE). El boton Anular queda deshabilitado si la factura ya esta
   `ANULADA`.

### Configuracion y perfiles

| Archivo | Para que |
|---|---|
| `application.properties` | comun: puerto, Jackson, `app.reportes.*`, `app.cors.*`, `springdoc.*`, perfil activo por defecto |
| `application-local.properties` | H2 en archivo, sin credenciales |
| `application-dev.properties` | MySQL remota, clave por `${DB_PASSWORD}`, `ddl-auto=update` |
| `application-prod.properties` | todo por variables de entorno, `ddl-auto=validate`, logging minimo |

`config/ReportesProperties` mapea el grupo `app.reportes.*` con `@ConfigurationProperties`,
que es lo que evita repartir media docena de `@Value` por las clases de reporte.

### Datos de prueba

`bootstrap/CargaDatosIniciales` es un `CommandLineRunner` con
`@ConditionalOnProperty("app.seed.enabled")`, y siembra 12 facturas solo si la tabla esta vacia.
El trabajo transaccional vive en `SeedDatosService`: si el metodo `@Transactional` estuviera en
el mismo runner, llamarlo desde `run()` seria una invocacion sobre `this` y se saltearia el
proxy que abre la transaccion.

## Dos cosas que costaron, por si reaparecen

1. **`@RequestParam` de fechas.** Spring parsea las fechas ISO de los parametros en **UTC**. Con
   `java.util.Date`, un `fechaHasta=2026-02-22` llegaba como las 21:00 del dia 21 en hora
   argentina y el filtro perdia las facturas de ese dia. La firma del controlador usa
   `LocalDate`, que no tiene zona, y la conversion a `Date` se hace una sola vez en
   `FacturaFiltro.de(...)`, anclando `fechaDesde` al inicio del dia y `fechaHasta` al final.

2. **Parametros `Date` en JPQL.** `setParameter(nombre, fecha)` con un `java.util.Date` lo bindea
   como `DATE` y descarta la hora. Hay que pasar el `TemporalType` explicito:
   `setParameter(nombre, fecha, TemporalType.TIMESTAMP)`.

## Desviaciones del enunciado, y por que

1. **Version de Springdoc.** El enunciado pide `springdoc-openapi-starter-webmvc-ui:2.5.0`, pero
   esa linea se escribio para Spring Boot 3.0 y con Spring Boot 3.5 (Spring Framework 6.2) el
   contexto de SpringDOC no levanta. Va la `2.8.9`, que es la linea que soporta Spring Boot 3.5.
2. **`DELETE` borra, `PUT /{id}/estado` anula.** El enunciado deja a criterio si la eliminacion
   es fisica o logica. Aqui el borrado es fisico (el boton "Eliminar") y la anulacion logica
   (estado `ANULADA` con su `fechaAnulacion`, el boton "Anular"), que es lo que corresponde a un
   sistema de facturacion: una factura emitida no se borra, se anula.
3. **`PUT /api/facturas/{id}` actualiza la factura completa.** El enunciado说的是 "los datos/estado
   a actualizar en el cuerpo". Se opto por un `PUT` con el `FacturaRequestDTO` completo (cabecera
   + items) y un `PUT` aparte para el estado, porque actualizar items y cambiar el estado son
   dos operaciones distintas: anular no tiene por que tocar los renglones.
4. **Se agrega `estado` al `FacturaReporteDTO`.** El enunciado no lo pide, pero el frontend
   necesita saber si una factura ya esta anulada para desactivar el boton "Anular".
